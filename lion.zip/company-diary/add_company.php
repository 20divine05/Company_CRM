<?php
require 'db.php';
if (!isset($_SESSION['user_id'])) { 
    header("Location: index.php"); 
    exit; 
}

$message = "";
$isSuccess = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $website = trim($_POST['website']);
    $status = $_POST['status'];
    $conversation_notes = trim($_POST['conversation_notes']);
    $reminder_period = $_POST['reminder_period'];
    $reminder_at = isset($_POST['reminder_at']) ? $_POST['reminder_at'] : null;
    $custom_reminder_days = $_POST['custom_reminder_days'] ? (int)$_POST['custom_reminder_days'] : null;
    
    // Primary contact info
    $contact_name = trim($_POST['contact_name']);
    $contact_role = trim($_POST['contact_role']);
    $contact_department = trim($_POST['contact_department']);
    $contact_email = trim($_POST['contact_email']);
    $contact_phone = trim($_POST['contact_phone']);
    
    // Optional follow-up
    $followup_description = trim($_POST['followup_description']);
    $followup_date = $_POST['followup_date'];
    $followup_time = $_POST['followup_time'];
    $followup_priority = $_POST['followup_priority'];
    $reminder_email = isset($_POST['reminder_email']) ? 1 : 0;
    $email_recipients = isset($_POST['email_recipients']) ? json_encode($_POST['email_recipients']) : null;
    
    if ($name) {
        try {
            $pdo->beginTransaction();
            
            $stmt = $pdo->prepare("INSERT INTO companies (name, website, status, conversation_notes, reminder_period, custom_reminder_days, reminder_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$name, $website, $status, $conversation_notes, $reminder_period, $custom_reminder_days, $reminder_at]);
            $company_id = $pdo->lastInsertId();
            
            if ($contact_name && !empty($contact_name)) {
                $stmt = $pdo->prepare("INSERT INTO company_people (company_id, name, role, department, email, phone, is_primary) VALUES (?, ?, ?, ?, ?, ?, 1)");
                $stmt->execute([$company_id, $contact_name, $contact_role, $contact_department, $contact_email, $contact_phone]);
            }
            
            if ($followup_description && !empty($followup_description) && $followup_date) {
                $stmt = $pdo->prepare("INSERT INTO follow_ups (company_id, description, date, time, priority, reminder_email, email_recipients) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$company_id, $followup_description, $followup_date, $followup_time, $followup_priority, $reminder_email, $email_recipients]);
            }
            
            $pdo->commit();
            $isSuccess = true;
            $message = "Company added successfully!";
            // Clear form
            $_POST = array();
        } catch (Exception $e) {
            $pdo->rollback();
            $message = "Error adding company: " . $e->getMessage();
        }
    } else {
        $message = "Company name is required.";
    }
}

$stmt = $pdo->prepare("SELECT email FROM users ORDER BY email");
$stmt->execute();
$all_users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Company - Company Diary</title>
    <style>
        /* Updated to match modern dashboard design with dark sidebar */
        :root {
            --sidebar-bg: #1a1d29;
            --sidebar-text: #a1a5b7;
            --sidebar-active: #3b82f6;
            --main-bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --gradient-1: linear-gradient(135deg, #06b6d4, #3b82f6);
            --gradient-2: linear-gradient(135deg, #ec4899, #8b5cf6);
            --gradient-3: linear-gradient(135deg, #f59e0b, #ef4444);
            --gradient-4: linear-gradient(135deg, #10b981, #059669);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: var(--main-bg);
            color: var(--text-dark);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }

        /* Added consistent sidebar navigation */
        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            color: var(--sidebar-text);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            z-index: 1000;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 2rem;
        }

        .sidebar-header h1 {
            color: white;
            font-size: 1.5rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .sidebar-header .user-info {
            margin-top: 1rem;
            font-size: 0.9rem;
            opacity: 0.8;
            font-weight: 500;
        }

        .sidebar-nav {
            list-style: none;
            padding: 0 1rem;
        }

        .sidebar-nav li {
            margin-bottom: 0.5rem;
        }

        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.875rem 1rem;
            color: var(--sidebar-text);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: var(--sidebar-active);
            color: white;
            transform: translateX(4px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .sidebar-nav .icon {
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
        }

        .main-header {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 20px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border);
        }

        .main-header h1 {
            font-size: 2rem;
            font-weight: 800;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .main-header .breadcrumb {
            color: var(--text-muted);
            font-size: 1rem;
            font-weight: 500;
        }

        .card {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2.5rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            margin-bottom: 2rem;
            border: 1px solid var(--border);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
        }

        .section-header {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--border);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
        }

        .form-row-3 {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 1.5rem;
            align-items: end;
        }

        .form-group {
            margin-bottom: 2rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.75rem;
            color: var(--text-dark);
            font-weight: 600;
            font-size: 0.95rem;
        }

        .form-control {
            width: 100%;
            padding: 1rem 1.25rem;
            border: 2px solid var(--border);
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: var(--card-bg);
            font-weight: 500;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--sidebar-active);
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
        }

        textarea.form-control {
            resize: vertical;
            min-height: 120px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem 2rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
            font-size: 1rem;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: var(--gradient-1);
            color: white;
        }

        .btn-secondary {
            background: var(--gradient-2);
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        .form-actions {
            display: flex;
            gap: 1.5rem;
            margin-top: 3rem;
        }

        .alert {
            padding: 1.25rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            font-weight: 600;
            font-size: 1rem;
        }

        .alert-success {
            background: linear-gradient(135deg, #f0fdf4, #dcfce7);
            color: var(--gradient-4);
            border: 1px solid #bbf7d0;
        }

        .alert-error {
            background: linear-gradient(135deg, #fef2f2, #fee2e2);
            color: var(--gradient-3);
            border: 1px solid #fecaca;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-top: 0.5rem;
        }

        .checkbox-group input[type="checkbox"] {
            width: auto;
            margin: 0;
            transform: scale(1.2);
        }

        .multi-select {
            min-height: 120px;
        }
        
        .custom-reminder-group {
            display: none;
            margin-top: 1rem;
        }
        
        .custom-reminder-group.show {
            display: block;
        }

        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }

            .main-content {
                margin-left: 0;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 1rem;
            }

            .form-actions {
                flex-direction: column;
            }

            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Added consistent sidebar navigation -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h1>📊 BRAND</h1>
            <div class="user-info">
                Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!
            </div>
        </div>
        <nav>
            <ul class="sidebar-nav">
                <li><a href="dashboard.php"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="companies.php" class="active"><span class="icon">🏢</span> Companies</a></li>
                <li><a href="follow_ups.php"><span class="icon">📝</span> Follow-ups</a></li>
                <li><a href="analytics.php"><span class="icon">📈</span> Analytics</a></li>
                <li><a href="reports.php"><span class="icon">📋</span> Reports</a></li>
                
                <li><a href="logout.php"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
    </aside>

    <main class="main-content">
        <div class="main-header">
            <h1>➕ Add New Company</h1>
            <div class="breadcrumb">Dashboard / Companies / Add Company</div>
        </div>

        <?php if ($message): ?>
            <div class="alert <?php echo $isSuccess ? 'alert-success' : 'alert-error'; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <!-- Company Information Section -->
            <div class="card">
                <h3 class="section-header">🏢 Company Information</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="name">Company Name *</label>
                        <input type="text" id="name" name="name" class="form-control" required 
                               value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="website">Website</label>
                        <input type="url" id="website" name="website" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['website'] ?? ''); ?>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status" class="form-control">
                            <option value="prospect" <?php echo ($_POST['status'] ?? '') === 'prospect' ? 'selected' : ''; ?>>Prospect</option>
                            <option value="active" <?php echo ($_POST['status'] ?? '') === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="interview_scheduled" <?php echo ($_POST['status'] ?? '') === 'interview_scheduled' ? 'selected' : ''; ?>>Interview Scheduled</option>
                            <option value="completed" <?php echo ($_POST['status'] ?? '') === 'completed' ? 'selected' : ''; ?>>Completed</option>
                            <option value="inactive" <?php echo ($_POST['status'] ?? '') === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="reminder_period">Reminder Period</label>
                        <select id="reminder_period" name="reminder_period" class="form-control" onchange="toggleCustomReminder()">
                            <option value="3_months" <?php echo ($_POST['reminder_period'] ?? '3_months') === '3_months' ? 'selected' : ''; ?>>3 Months</option>
                            <option value="6_months" <?php echo ($_POST['reminder_period'] ?? '') === '6_months' ? 'selected' : ''; ?>>6 Months</option>
                            <option value="1_year" <?php echo ($_POST['reminder_period'] ?? '') === '1_year' ? 'selected' : ''; ?>>1 Year</option>
                            <option value="custom" <?php echo ($_POST['reminder_period'] ?? '') === 'custom' ? 'selected' : ''; ?>>Custom</option>
                        </select>
                    </div>
                </div>

                <div class="custom-reminder-group" id="customReminderGroup">
                    <div class="form-group">
                        <label for="custom_reminder_days">Custom Reminder (Days)</label>
                        <input type="number" id="custom_reminder_days" name="custom_reminder_days" class="form-control" 
                               min="1" value="<?php echo htmlspecialchars($_POST['custom_reminder_days'] ?? ''); ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="conversation_notes">Conversation Notes</label>
                    <textarea id="conversation_notes" name="conversation_notes" class="form-control"><?php echo htmlspecialchars($_POST['conversation_notes'] ?? ''); ?></textarea>
                </div>
            </div>

            <!-- Primary Contact Section -->
            <div class="card">
                <h3 class="section-header">👤 Primary Contact</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="contact_name">Contact Name</label>
                        <input type="text" id="contact_name" name="contact_name" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['contact_name'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="contact_role">Role/Position</label>
                        <input type="text" id="contact_role" name="contact_role" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['contact_role'] ?? ''); ?>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="contact_department">Department</label>
                        <select id="contact_department" name="contact_department" class="form-control">
                            <option value="">-- Select Department --</option>
                            <option value="CSE" <?= ($_POST['contact_department'] ?? '') === 'CSE' ? 'selected' : ''; ?>>CSE</option>
                            <option value="ISE" <?= ($_POST['contact_department'] ?? '') === 'ISE' ? 'selected' : ''; ?>>ISE</option>
                            <option value="AI&ML" <?= ($_POST['contact_department'] ?? '') === 'AI&ML' ? 'selected' : ''; ?>>AI & ML</option>
                            <option value="ECE" <?= ($_POST['contact_department'] ?? '') === 'ECE' ? 'selected' : ''; ?>>ECE</option>
                            <option value="EEE" <?= ($_POST['contact_department'] ?? '') === 'EEE' ? 'selected' : ''; ?>>EEE</option>
                            <option value="ME" <?= ($_POST['contact_department'] ?? '') === 'ME' ? 'selected' : ''; ?>>ME</option>
                            <option value="CV" <?= ($_POST['contact_department'] ?? '') === 'CV' ? 'selected' : ''; ?>>CV</option>
                            <option value="MBA" <?= ($_POST['contact_department'] ?? '') === 'MBA' ? 'selected' : ''; ?>>MBA</option>
                            <option value="MCA" <?= ($_POST['contact_department'] ?? '') === 'MCA' ? 'selected' : ''; ?>>MCA</option>
                            <option value="MTECH" <?= ($_POST['contact_department'] ?? '') === 'MTECH' ? 'selected' : ''; ?>>MTECH</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="contact_email">Email</label>
                        <input type="email" id="contact_email" name="contact_email" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['contact_email'] ?? ''); ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="contact_phone">Phone Number</label>
                    <input type="tel" id="contact_phone" name="contact_phone" class="form-control" 
                           value="<?php echo htmlspecialchars($_POST['contact_phone'] ?? ''); ?>">
                </div>
            </div>

            <!-- Optional Follow-up Section -->
            <div class="card">
                <h3 class="section-header">📅 Optional Follow-up</h3>
                
                <div class="form-group">
                    <label for="followup_description">Follow-up Description</label>
                    <textarea id="followup_description" name="followup_description" class="form-control"><?php echo htmlspecialchars($_POST['followup_description'] ?? ''); ?></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="followup_date">Follow-up Date</label>
                        <input type="date" id="followup_date" name="followup_date" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['followup_date'] ?? ''); ?>">
                    </div>

                    <div class="form-group">
                        <label for="followup_time">Follow-up Time</label>
                        <input type="time" id="followup_time" name="followup_time" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['followup_time'] ?? ''); ?>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="followup_priority">Priority</label>
                        <select id="followup_priority" name="followup_priority" class="form-control">
                            <option value="low" <?php echo ($_POST['followup_priority'] ?? '') === 'low' ? 'selected' : ''; ?>>Low</option>
                            <option value="medium" <?php echo ($_POST['followup_priority'] ?? 'medium') === 'medium' ? 'selected' : ''; ?>>Medium</option>
                            <option value="high" <?php echo ($_POST['followup_priority'] ?? '') === 'high' ? 'selected' : ''; ?>>High</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>&nbsp;</label>
                        <div class="checkbox-group">
                            <input type="checkbox" id="reminder_email" name="reminder_email" 
                                   <?php echo isset($_POST['reminder_email']) ? 'checked' : ''; ?>>
                            <label for="reminder_email">Send reminder email</label>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="email_recipients">Email Recipients (for reminders)</label>
                    <select id="email_recipients" name="email_recipients[]" class="form-control multi-select" multiple>
                        <?php foreach ($all_users as $user): ?>
                            <option value="<?= htmlspecialchars($user['email']) ?>" 
                                    <?= (isset($_POST['email_recipients']) && in_array($user['email'], $_POST['email_recipients'])) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($user['email']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <small style="color: var(--text-muted);">Hold Ctrl/Cmd to select multiple emails</small>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">💾 Save Company</button>
                <a href="companies.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </main>

    <script>
        function toggleCustomReminder() {
            var datetimeGroup = document.getElementById('customDatetime');
            const reminderPeriod = document.getElementById('reminder_period').value;
            const customGroup = document.getElementById('customReminderGroup');
            
            if (reminderPeriod === 'custom') {
                if (datetimeGroup) datetimeGroup.style.display = 'none';
                customGroup.classList.add('show');
            } else if (reminderPeriod === 'custom_datetime') {
                if (datetimeGroup) datetimeGroup.style.display = 'block';
            } else {
                customGroup.classList.remove('show');
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            toggleCustomReminder();
        });
    </script>
</body>
</html>
