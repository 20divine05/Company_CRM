<?php
require 'db.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

try {
    // Get updated follow-up counts and statuses
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN status = 'pending' AND CONCAT(date, ' ', IFNULL(time,'09:00:00')) <= NOW() THEN 1 ELSE 0 END) as overdue
        FROM follow_ups f 
        JOIN companies c ON f.company_id = c.id 
        WHERE c.user_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $stats = $stmt->fetch();
    
    // Get recently updated follow-ups (last 5 minutes)
    $stmt = $pdo->prepare("
        SELECT f.id, f.status, f.email_sent, c.name as company_name
        FROM follow_ups f 
        JOIN companies c ON f.company_id = c.id 
        WHERE c.user_id = ? 
        AND (f.updated_at >= DATE_SUB(NOW(), INTERVAL 5 MINUTE) OR f.completed_at >= DATE_SUB(NOW(), INTERVAL 5 MINUTE))
        ORDER BY COALESCE(f.completed_at, f.updated_at) DESC
        LIMIT 10
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $recent_updates = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'stats' => $stats,
        'recent_updates' => $recent_updates,
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
