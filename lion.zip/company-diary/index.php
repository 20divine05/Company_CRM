<?php
include "db.php";

$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            header("Location: dashboard.php");
            exit;
        } else { 
            $error = "Invalid password."; 
        }
    } else { 
        $error = "User not found."; 
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Company Diary • Login</title>
<style>
:root {
    --primary: #3b82f6;
    --primary-dark: #1d4ed8;
    --secondary: #10b981;
    --accent: #f59e0b;
    --danger: #ef4444;
    --bg-dark: #0f172a;
    --bg-darker: #020617;
    --bg-card: #1e293b;
    --text-light: #f8fafc;
    --text-muted: #94a3b8;
    --border: #334155;
    --gradient-primary: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    --gradient-accent: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
    background: var(--bg-darker);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    position: relative;
    overflow: hidden;
}

body::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: var(--gradient-primary);
    opacity: 0.1;
    z-index: -1;
}

.container {
    background: rgba(30, 41, 59, 0.95);
    backdrop-filter: blur(20px);
    border-radius: 24px;
    padding: 48px;
    box-shadow: var(--shadow-lg);
    width: 100%;
    max-width: 440px;
    border: 1px solid var(--border);
    position: relative;
}

.container::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: var(--gradient-primary);
    border-radius: 24px 24px 0 0;
}

.brand {
    text-align: center;
    margin-bottom: 40px;
}

.brand h1 {
    color: var(--text-light);
    font-size: 32px;
    font-weight: 800;
    margin-bottom: 12px;
    background: var(--gradient-primary);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.brand p {
    color: var(--text-muted);
    font-size: 16px;
    font-weight: 500;
}

.form-group {
    margin-bottom: 24px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    color: var(--text-light);
    font-weight: 600;
    font-size: 14px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.form-control {
    width: 100%;
    padding: 16px 20px;
    border: 2px solid var(--border);
    border-radius: 12px;
    font-size: 16px;
    transition: all 0.3s ease;
    background: var(--bg-card);
    color: var(--text-light);
}

.form-control:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.15);
    background: rgba(30, 41, 59, 0.8);
}

.form-control::placeholder {
    color: var(--text-muted);
}

.btn {
    width: 100%;
    padding: 16px;
    border: none;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    display: inline-block;
    text-align: center;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.btn-primary {
    background: var(--gradient-primary);
    color: white;
    position: relative;
    overflow: hidden;
}

.btn-primary::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    transition: left 0.5s;
}

.btn-primary:hover::before {
    left: 100%;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 20px 40px rgba(102, 126, 234, 0.4);
}

.error {
    background: rgba(239, 68, 68, 0.1);
    color: var(--danger);
    padding: 16px;
    border-radius: 12px;
    margin-top: 20px;
    font-size: 14px;
    border: 1px solid rgba(239, 68, 68, 0.2);
    font-weight: 500;
}

.footer {
    text-align: center;
    margin-top: 32px;
    color: var(--text-muted);
    font-size: 14px;
}

.footer a {
    color: var(--primary);
    text-decoration: none;
    font-weight: 600;
    transition: color 0.3s ease;
}

.footer a:hover {
    color: var(--primary-dark);
    text-decoration: underline;
}

@media (max-width: 480px) {
    .container {
        padding: 32px 24px;
        margin: 16px;
    }
    
    .brand h1 {
        font-size: 28px;
    }
}
</style>
</head>
<body>
<div class="container">
    <div class="brand">
        <h1>Company Diary</h1>
        <p>Your Personal CRM System</p>
    </div>
    
    <form method="POST">
        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email" required>
        </div>
        
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" required>
        </div>
        
        <button type="submit" class="btn btn-primary">Sign In</button>
        
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
    </form>
    
    <div class="footer">
        Don't have an account? <a href="register.php">Create one here</a>
    </div>
</div>
</body>
</html>
