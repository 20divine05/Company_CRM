<?php
require 'db.php';
require 'email_config.php';

function checkReminders() {
    global $pdo;

    error_log("🚀 STARTING REMINDER CHECK at: " . date('Y-m-d H:i:s'));
// removed auto testEmailConnection() check
// Follow-up reminders
    $stmt = $pdo->prepare("
        SELECT f.*, c.name AS company_name, c.user_id
        FROM follow_ups f
        JOIN companies c ON f.company_id = c.id
        WHERE f.status = 'pending'
          AND f.reminder_email = 1
          AND f.email_sent = 0
          AND CONCAT(f.date, ' ', IFNULL(f.time,'09:00:00')) <= NOW()
    ");
    $stmt->execute();
    $followups = $stmt->fetchAll();

    error_log("📧 Found " . count($followups) . " follow-ups ready for email reminders");

    foreach ($followups as $f) {
        $emailSent = false;
        $emailError = '';
        
        error_log("⏰ Processing follow-up ID {$f['id']} for company: {$f['company_name']}");
        error_log("📅 Scheduled: {$f['date']} {$f['time']} | Current: " . date('Y-m-d H:i:s'));
        
        if ($f['email_recipients']) {
            $recipients = json_decode($f['email_recipients'], true);
            if ($recipients && count($recipients) > 0) {
                
                $maxRetries = 3;
                $retryCount = 0;
                
                while ($retryCount < $maxRetries && !$emailSent) {
                    $retryCount++;
                    error_log("📤 Attempt {$retryCount}/{$maxRetries} for follow-up ID {$f['id']}");
                    
                    $scheduled_datetime = $f['date'] . ' ' . ($f['time'] ?? '09:00:00');
                    if (sendFollowUpEmail($recipients, $f['company_name'], $f['description'], $scheduled_datetime, $f['priority'])) {
                        $emailSent = true;
                        error_log("✅ EMAIL SUCCESS: Follow-up ID {$f['id']} on attempt {$retryCount}");
                        break;
                    } else {
                        $emailError = "Failed after {$retryCount} attempts";
                        error_log("❌ EMAIL FAILED: Follow-up ID {$f['id']} attempt {$retryCount}");
                        
                        if ($retryCount < $maxRetries) {
                            sleep(10);
                        }
                    }
                }
            } else {
                $emailError = "No valid email recipients";
                error_log("⚠️ No valid recipients for follow-up ID {$f['id']}");
            }
        } else {
            $emailError = "No email recipients configured";
            error_log("⚠️ No recipients configured for follow-up ID {$f['id']}");
        }

        $pdo->beginTransaction();
        try {
            // Check if completed_at column exists
            $columnCheck = $pdo->query("SHOW COLUMNS FROM follow_ups LIKE 'completed_at'");
            $hasCompletedAtColumn = $columnCheck->rowCount() > 0;
            
            if ($emailSent) {
                // Email sent successfully - mark as completed
                if ($hasCompletedAtColumn) {
                    $update = $pdo->prepare("UPDATE follow_ups SET email_sent = 1, status = 'completed', completed_at = NOW(), updated_at = NOW() WHERE id = ?");
                    $update->execute([$f['id']]);
                } else {
                    $update = $pdo->prepare("UPDATE follow_ups SET email_sent = 1, status = 'completed', updated_at = NOW() WHERE id = ?");
                    $update->execute([$f['id']]);
                }
                error_log("🎯 COMPLETED WITH EMAIL: Follow-up ID {$f['id']}");
            } else {
                // Email failed - DO NOT mark as completed, just log the error
                // Add error note but keep status as pending so it will retry next time
                $errorNote = "[EMAIL FAILED " . date('Y-m-d H:i:s') . "] " . $emailError;
                
                // Check if notes column exists
                $notesCheck = $pdo->query("SHOW COLUMNS FROM follow_ups LIKE 'notes'");
                $hasNotesColumn = $notesCheck->rowCount() > 0;
                
                if ($hasNotesColumn) {
                    $update = $pdo->prepare("UPDATE follow_ups SET updated_at = NOW(), notes = CONCAT(IFNULL(notes, ''), '\n', ?) WHERE id = ?");
                    $update->execute([$errorNote, $f['id']]);
                } else {
                    $update = $pdo->prepare("UPDATE follow_ups SET updated_at = NOW() WHERE id = ?");
                    $update->execute([$f['id']]);
                }
                error_log("🔄 KEPT PENDING: Follow-up ID {$f['id']} will retry next time - " . $emailError);
            }
            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollback();
            error_log("💥 DB ERROR for follow-up ID {$f['id']}: " . $e->getMessage());
        }
    }

    // Company reminders
    $stmt = $pdo->prepare("
        SELECT c.*, u.email AS user_email
        FROM companies c
        JOIN users u ON c.user_id = u.id
        WHERE (
            (c.reminder_period = '3_months' AND c.created_at <= DATE_SUB(NOW(), INTERVAL 3 MONTH)) OR
            (c.reminder_period = '6_months' AND c.created_at <= DATE_SUB(NOW(), INTERVAL 6 MONTH)) OR
            (c.reminder_period = '1_year' AND c.created_at <= DATE_SUB(NOW(), INTERVAL 1 YEAR)) OR
            (c.reminder_period = 'custom' AND c.custom_reminder_days IS NOT NULL AND c.created_at <= DATE_SUB(NOW(), INTERVAL c.custom_reminder_days DAY))
            OR (c.reminder_period = 'custom_datetime' AND c.reminder_at IS NOT NULL AND c.reminder_at <= NOW())
        )
        AND (c.last_reminder_sent IS NULL OR c.last_reminder_sent <= DATE_SUB(NOW(), INTERVAL 1 WEEK))
    ");
    $stmt->execute();
    $companies = $stmt->fetchAll();

    error_log("🔍 Found " . count($companies) . " companies ready for reminders");

    foreach ($companies as $c) {
        $days_since = floor((time() - strtotime($c['created_at'])) / (60*60*24));
        $subject = "Company Reminder: " . $c['name'];
        $body = "
            <h3>Company Follow-up Reminder</h3>
            <p><strong>Company:</strong> {$c['name']}</p>
            <p><strong>Status:</strong> " . ucfirst($c['status']) . "</p>
            <p><strong>Days since added:</strong> {$days_since} days</p>
            <p><strong>Website:</strong> " . ($c['website'] ? $c['website'] : 'Not provided') . "</p>
            <p>Please log in to Company Diary CRM to manage this company.</p>
        ";

        $maxRetries = 3;
        $retryCount = 0;
        $emailSent = false;
        
        while ($retryCount < $maxRetries && !$emailSent) {
            $retryCount++;
            if (sendEmail($c['user_email'], $subject, $body, true)) {
                $emailSent = true;
                error_log("💌 Company reminder sent for: {$c['name']} on attempt {$retryCount}");
            } else {
                error_log("🚫 Company reminder failed for: {$c['name']} on attempt {$retryCount}");
                if ($retryCount < $maxRetries) {
                    sleep(5);
                }
            }
        }
        
        $update = $pdo->prepare("UPDATE companies SET last_reminder_sent = NOW() WHERE id = ?");
        $update->execute([$c['id']]);
        
        if (!$emailSent) {
            error_log("💔 FINAL FAILURE: Company reminder for {$c['name']} failed after {$maxRetries} attempts, but timestamp updated");
        }
    }

    error_log("🏁 REMINDER CHECK COMPLETED at: " . date('Y-m-d H:i:s'));
}

// SAFE_INCLUDE_GUARD: only run automatically if executed directly
if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'] ?? '')) {
try {
    checkReminders();
    echo "✅ Reminder check completed successfully at " . date('Y-m-d H:i:s') . "\n";
} catch (Exception $e) {
    error_log("💥 CRITICAL ERROR during reminder check: " . $e->getMessage());
    echo "❌ Error during reminder check: " . $e->getMessage() . "\n";
}
}
?>
