<?php
// This file should be set up as a cron job to run every minute or every 5 minutes
// Example cron job: */5 * * * * /usr/bin/php /path/to/your/project/cron_reminder.php

try {
    // Set the path to your project directory - use absolute path for cron jobs
    $project_path = __DIR__;

    // Change to project directory
    chdir($project_path);

    ob_start();
    
    // Include the reminder check script
    include 'check_reminders.php';
    
    $output = ob_get_clean();

    // Log the execution with more details
    $log_message = date('Y-m-d H:i:s') . " - Cron reminder check executed successfully\n";
    if ($output) {
        $log_message .= "Output: " . $output . "\n";
    }
    
    $log_message .= "Memory used: " . memory_get_peak_usage(true) / 1024 / 1024 . " MB\n";
    $log_message .= "Execution time: " . (microtime(true) - $_SERVER['REQUEST_TIME_FLOAT']) . " seconds\n";
    $log_message .= "---\n";
    
    file_put_contents('cron_log.txt', $log_message, FILE_APPEND | LOCK_EX);
    
} catch (Exception $e) {
    $error_message = date('Y-m-d H:i:s') . " - Cron reminder check FAILED: " . $e->getMessage() . "\n";
    $error_message .= "Stack trace: " . $e->getTraceAsString() . "\n";
    $error_message .= "---\n";
    file_put_contents('cron_log.txt', $error_message, FILE_APPEND | LOCK_EX);
    error_log("Cron reminder check failed: " . $e->getMessage());
}
?>
