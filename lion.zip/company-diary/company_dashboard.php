<?php
require 'db.php';
if (!isset($_SESSION['user_id'])) { 
    header("Location: index.php"); 
    exit; 
}

$company_id = $_GET['id'] ?? null;
if (!$company_id) {
    header("Location: companies.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM companies WHERE id = ?");
$stmt->execute([$company_id]);
$company = $stmt->fetch();

if (!$company) {
    header("Location: companies.php");
    exit;
}




$user_id = $_SESSION['user_id'];

// Get people count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM company_people WHERE company_id = ?");
$stmt->execute([$company_id]);
$people_count = $stmt->fetchColumn();

// Get pending follow-ups count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM follow_ups WHERE company_id = ? AND status = 'pending'");
$stmt->execute([$company_id]);
$pending_followups = $stmt->fetchColumn();

// Get notes count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM company_notes WHERE company_id = ?");
$stmt->execute([$company_id]);
$notes_count = $stmt->fetchColumn();

// Get links count
$stmt = $pdo->prepare("SELECT COUNT(*) FROM company_links WHERE company_id = ?");
$stmt->execute([$company_id]);
$links_count = $stmt->fetchColumn();

if ($_POST['action'] ?? '' === 'add_note') {
    $note = trim($_POST['note'] ?? '');
    if (!empty($note)) {
        $stmt = $pdo->prepare("INSERT INTO company_notes (company_id, note) VALUES (?, ?)");
        $stmt->execute([$company_id, $note]);
        header("Location: company_dashboard.php?id=$company_id&success=note_added");
        exit;
    }
}

if ($_GET['delete_note'] ?? false) {
    $note_id = (int)$_GET['delete_note'];
    $stmt = $pdo->prepare("DELETE FROM company_notes WHERE id = ? AND company_id = ?");
    $stmt->execute([$note_id, $company_id]);
    header("Location: company_dashboard.php?id=$company_id&success=note_deleted");
    exit;
}

if ($_POST['action'] ?? '' === 'add_link') {
    $link_name = trim($_POST['link_name'] ?? '');
    $link_url = trim($_POST['link_url'] ?? '');
    if (!empty($link_name) && !empty($link_url)) {
        // Add http:// if no protocol specified
        if (!preg_match('/^https?:\/\//', $link_url)) {
            $link_url = 'http://' . $link_url;
        }
        $stmt = $pdo->prepare("INSERT INTO company_links (company_id, name, url) VALUES (?, ?, ?)");
        $stmt->execute([$company_id, $link_name, $link_url]);
        header("Location: company_dashboard.php?id=$company_id&success=link_added");
        exit;
    }
}

if ($_GET['delete_link'] ?? false) {
    $link_id = (int)$_GET['delete_link'];
    $stmt = $pdo->prepare("DELETE FROM company_links WHERE id = ? AND company_id = ?");
    $stmt->execute([$link_id, $company_id]);
    header("Location: company_dashboard.php?id=$company_id&success=link_deleted");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM company_notes WHERE company_id = ? ORDER BY created_at DESC LIMIT 5");
$stmt->execute([$company_id]);
$recent_notes = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM company_links WHERE company_id = ? ORDER BY created_at DESC LIMIT 10");
$stmt->execute([$company_id]);
$recent_links = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM follow_ups WHERE company_id = ? ORDER BY date DESC, time DESC LIMIT 5");
$stmt->execute([$company_id]);
$recent_followups = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM company_people WHERE company_id = ? ORDER BY created_at DESC LIMIT 5");
$stmt->execute([$company_id]);
$recent_people = $stmt->fetchAll();


$stmt = $pdo->prepare("SELECT * FROM company_people WHERE company_id = ? AND is_primary = 1 ORDER BY id DESC LIMIT 1");
$stmt->execute([$company_id]);
$primary_person = $stmt->fetch();


$stmt = $pdo->prepare("SELECT department FROM company_people WHERE company_id = ? AND is_primary = 1 ORDER BY id DESC LIMIT 1");
$stmt->execute([$company_id]);
$primary_department = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($company['name']) ?> - Company Dashboard</title>
    <style>
        :root {
            --sidebar-bg: #1a1d29;
            --sidebar-text: #a1a5b7;
            --sidebar-active: #3b82f6;
            --main-bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --gradient-1: linear-gradient(135deg, #06b6d4, #3b82f6);
            --gradient-2: linear-gradient(135deg, #ec4899, #8b5cf6);
            --gradient-3: linear-gradient(135deg, #f59e0b, #ef4444);
            --gradient-4: linear-gradient(135deg, #10b981, #059669);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: var(--main-bg);
            color: var(--text-dark);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            color: var(--sidebar-text);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            z-index: 1000;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 2rem;
        }

        .sidebar-header h1 {
            color: white;
            font-size: 1.5rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .sidebar-header .user-info {
            margin-top: 1rem;
            font-size: 0.9rem;
            opacity: 0.8;
            font-weight: 500;
        }

        .sidebar-nav {
            list-style: none;
            padding: 0 1rem;
        }

        .sidebar-nav li {
            margin-bottom: 0.5rem;
        }

        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.875rem 1rem;
            color: var(--sidebar-text);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: var(--sidebar-active);
            color: white;
            transform: translateX(4px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .sidebar-nav .icon {
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
        }

        .company-header {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            border: 1px solid var(--border);
        }

        .company-title {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--text-dark);
            margin-bottom: 1rem;
        }

        .company-meta {
            display: flex;
            gap: 2rem;
            align-items: center;
            flex-wrap: wrap;
        }

        .status-badge {
            padding: 0.75rem 1.5rem;
            border-radius: 25px;
            font-size: 0.9rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-prospect { 
            background: linear-gradient(135deg, #fef3c7, #fde68a);
            color: #92400e; 
        }
        .status-active { 
            background: linear-gradient(135deg, #d1fae5, #a7f3d0);
            color: #065f46; 
        }
        .status-client { 
            background: linear-gradient(135deg, #dbeafe, #bfdbfe);
            color: #1e40af; 
        }
        .status-inactive { 
            background: linear-gradient(135deg, #fee2e2, #fecaca);
            color: #991b1b; 
        }
        .status-interview_scheduled {
            background: linear-gradient(135deg, #e0e7ff, #c7d2fe);
            color: #3730a3;
        }
        .status-completed {
            background: linear-gradient(135deg, #dcfce7, #bbf7d0);
            color: #065f46;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            text-align: center;
            border: 1px solid var(--border);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: var(--gradient-1);
            border-radius: 20px 20px 0 0;
        }

        .stat-card:nth-child(2)::before { background: var(--gradient-2); }
        .stat-card:nth-child(3)::before { background: var(--gradient-3); }
        .stat-card:nth-child(4)::before { background: var(--gradient-4); }

        .stat-number {
            font-size: 3rem;
            font-weight: 800;
            margin-bottom: 0.75rem;
            background: var(--gradient-1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-card:nth-child(2) .stat-number {
            background: var(--gradient-2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-card:nth-child(3) .stat-number {
            background: var(--gradient-3);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-card:nth-child(4) .stat-number {
            background: var(--gradient-4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-label {
            color: var(--text-muted);
            font-size: 1rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .action-card {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            border: 1px solid var(--border);
            transition: all 0.3s ease;
        }

        .action-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
        }

        .action-title {
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem 1.5rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
            font-size: 0.95rem;
            width: 100%;
            justify-content: center;
            margin-bottom: 1rem;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary { background: var(--gradient-1); color: white; }
        .btn-secondary { background: var(--gradient-2); color: white; }
        .btn-warning { background: var(--gradient-3); color: white; }
        .btn-danger { background: var(--gradient-4); color: white; }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
        }

        .card {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            margin-bottom: 2rem;
            border: 1px solid var(--border);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
        }

        .card-title {
            font-size: 1.4rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .note-item {
            padding: 1.25rem;
            border: 1px solid var(--border);
            border-radius: 12px;
            margin-bottom: 1.25rem;
            position: relative;
            transition: all 0.3s ease;
        }

        .note-item:hover {
            background: #f8fafc;
            border-color: var(--sidebar-active);
        }

        .note-content {
            margin-bottom: 0.75rem;
            font-weight: 500;
        }

        .note-meta {
            font-size: 0.85rem;
            color: var(--text-muted);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .delete-note {
            color: var(--gradient-3);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-control {
            width: 100%;
            padding: 1rem 1.25rem;
            border: 2px solid var(--border);
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: var(--card-bg);
            font-weight: 500;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--sidebar-active);
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
        }

        .contact-info {
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            border: 1px solid var(--border);
        }

        .followup-item {
            padding: 1.25rem;
            border-left: 4px solid var(--sidebar-active);
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
            margin-bottom: 1.25rem;
            border-radius: 0 12px 12px 0;
            transition: all 0.3s ease;
        }

        .followup-item:hover {
            transform: translateX(4px);
        }

        .priority-high { border-left-color: #ef4444; }
        .priority-medium { border-left-color: #f59e0b; }
        .priority-low { border-left-color: #10b981; }

        .notes-section, .links-section {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            margin-bottom: 2rem;
            border: 1px solid var(--border);
        }
        
        .add-form {
            background: linear-gradient(135deg, #f8fafc, #f1f5f9);
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            border: 1px solid var(--border);
        }
        
        .form-row {
            display: flex;
            gap: 1rem;
            align-items: end;
        }
        
        .form-row .form-group {
            flex: 1;
            margin-bottom: 0;
        }
        
        .btn-small {
            padding: 0.75rem 1rem;
            font-size: 0.9rem;
            white-space: nowrap;
        }
        
        .link-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            border: 1px solid var(--border);
            border-radius: 12px;
            margin-bottom: 1rem;
            transition: all 0.3s ease;
        }
        
        .link-item:hover {
            background: #f8fafc;
            border-color: var(--sidebar-active);
        }
        
        .link-info {
            flex: 1;
        }
        
        .link-name {
            font-weight: 600;
            margin-bottom: 0.25rem;
        }
        
        .link-url {
            color: var(--sidebar-active);
            text-decoration: none;
            font-size: 0.9rem;
        }
        
        .link-url:hover {
            text-decoration: underline;
        }
        
        .link-actions {
            display: flex;
            gap: 0.5rem;
            align-items: center;
        }
        
        .delete-link {
            color: #ef4444;
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 600;
            padding: 0.25rem 0.5rem;
            border-radius: 6px;
            transition: all 0.3s ease;
        }
        
        .delete-link:hover {
            background: #fee2e2;
        }
        
        .success-message {
            background: linear-gradient(135deg, #d1fae5, #a7f3d0);
            color: #065f46;
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            font-weight: 600;
            border: 1px solid #10b981;
        }
        
        .empty-state {
            text-align: center;
            padding: 2rem;
            color: var(--text-muted);
            font-style: italic;
        }

        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }

            .main-content {
                margin-left: 0;
            }

            .content-grid { 
                grid-template-columns: 1fr; 
            }
        }

        @media (max-width: 768px) { 
            .main-content { 
                padding: 1rem; 
            }
            .company-meta { 
                flex-direction: column; 
                align-items: flex-start; 
            } 
        }
    </style>
</head>
<body>
    <aside class="sidebar">
        <div class="sidebar-header">
            <h1>📊 BRAND</h1>
            <div class="user-info">
                Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!
            </div>
        </div>
        <nav>
            <ul class="sidebar-nav">
                <li><a href="dashboard.php"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="companies.php" class="active"><span class="icon">🏢</span> Companies</a></li>
                <li><a href="follow_ups.php"><span class="icon">📝</span> Follow-ups</a></li>
                <li><a href="analytics.php"><span class="icon">📈</span> Analytics</a></li>
                <li><a href="reports.php"><span class="icon">📋</span> Reports</a></li>
                
                <li><a href="logout.php"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
    </aside>

    <main class="main-content">
        <?php if ($_GET['success'] ?? false): ?>
            <div class="success-message">
                <?php
                switch ($_GET['success']) {
                    case 'note_added': echo '✅ Note added successfully!'; break;
                    case 'note_deleted': echo '✅ Note deleted successfully!'; break;
                    case 'link_added': echo '✅ Link added successfully!'; break;
                    case 'link_deleted': echo '✅ Link deleted successfully!'; break;
                }
                ?>
            </div>
        <?php endif; ?>

        <div class="company-header">
            <h1 class="company-title"><?= htmlspecialchars($company['name']) ?></h1>
            <div class="company-meta">
                <span class="status-badge status-<?= $company['status'] ?>">
                    <?= ucfirst($company['status']) ?>
                </span>
                <?php if ($company['website']): ?>
                    <a href="<?= htmlspecialchars($company['website']) ?>" target="_blank" style="color: var(--sidebar-active); font-weight: 600;">
                        🌐 <?= htmlspecialchars($company['website']) ?>
                    </a>
                <?php endif; ?>
                <span style="color: var(--text-muted); font-weight: 500;">
                    Added <?= date('M j, Y', strtotime($company['created_at'])) ?>
                </span>
                <?php if (!empty($primary_person['department'])): ?>
                <span style="color: var(--text-muted); font-weight: 600;">
                    Dept: <?= htmlspecialchars($primary_person['department']) ?>
                </span>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($company['conversation_notes'])): ?>
                <div style="margin-top: 1.5rem; padding: 1.5rem; background: linear-gradient(135deg, #f0f9ff, #e0f2fe); border-radius: 12px; border-left: 4px solid var(--sidebar-active);">
                    <h3 style="color: var(--text-dark); font-size: 1.1rem; font-weight: 700; margin-bottom: 0.75rem; display: flex; align-items: center; gap: 0.5rem;">
                         Initial Conversation Notes
                    </h3>
                    <div style="color: var(--text-dark); font-weight: 500; line-height: 1.6;">
                        <?= nl2br(htmlspecialchars($company['conversation_notes'])) ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?= $people_count ?></div>
                <div class="stat-label">People</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $pending_followups ?></div>
                <div class="stat-label">Pending Follow-ups</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $notes_count ?></div>
                <div class="stat-label">Notes</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $links_count ?></div>
                <div class="stat-label">Links</div>
            </div>
        </div>

        <div class="actions-grid">
            <div class="action-card">
                <h3 class="action-title">👥 Manage People</h3>
                <a href="people.php?company_id=<?= $company_id ?>" class="btn btn-primary">View All People</a>
                <a href="add_person.php?company_id=<?= $company_id ?>" class="btn btn-secondary">Add New Person</a>
            </div>
            <div class="action-card">
                <h3 class="action-title">📅 Follow-ups</h3>
                <a href="follow_ups.php?company_id=<?= $company_id ?>" class="btn btn-primary">View All Follow-ups</a>
                <a href="add_followup.php?company_id=<?= $company_id ?>" class="btn btn-warning">Schedule Follow-up</a>
            </div>
            <div class="action-card">
                <h3 class="action-title">✏️ Quick Actions</h3>
                <a href="edit_company.php?id=<?= $company_id ?>" class="btn btn-primary">Edit Company</a>
                <a href="#notes-section" class="btn btn-secondary">Add Note</a>
                <?php if (!empty($company['conversation_notes']) || !empty($company['website'])): ?>
                    <button onclick="toggleCompanyInfo()" class="btn btn-warning" id="toggleInfoBtn">Show All Info</button>
                <?php endif; ?>
            </div>
        </div>

        <div class="content-grid">
            <div>
                <!-- Notes Section -->
                <div class="notes-section" id="notes-section">
                    <h3 class="card-title">📝 Company Notes</h3>
                    
                    <!-- Add Note Form -->
                    <div class="add-form">
                        <form method="POST">
                            <input type="hidden" name="action" value="add_note">
                            <div class="form-group">
                                <textarea name="note" class="form-control" rows="3" placeholder="Add a note about this company..." required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary btn-small">Add Note</button>
                        </form>
                    </div>
                    
                    <!-- Recent Notes -->
                    <?php if (empty($recent_notes)): ?>
                        <div class="empty-state">
                            No notes yet. Add your first note above!
                        </div>
                    <?php else: ?>
                        <?php foreach ($recent_notes as $note): ?>
                            <div class="note-item">
                                <div class="note-content"><?= nl2br(htmlspecialchars($note['note'])) ?></div>
                                <div class="note-meta">
                                    <span><?= date('M j, Y g:i A', strtotime($note['created_at'])) ?></span>
                                    <a href="?id=<?= $company_id ?>&delete_note=<?= $note['id'] ?>" 
                                       class="delete-note" 
                                       onclick="return confirm('Delete this note?')">Delete</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Links Section -->
                <div class="links-section" id="links-section">
                    <h3 class="card-title">🔗 Important Links</h3>
                    
                    <!-- Add Link Form -->
                    <div class="add-form">
                        <form method="POST">
                            <input type="hidden" name="action" value="add_link">
                            <div class="form-group">
                                <input type="text" name="link_name" class="form-control" placeholder="Link name (e.g., LinkedIn Profile, Company Portal, Documentation)" required style="margin-bottom: 1rem;">
                            </div>
                            <div class="form-group">
                                <input type="url" name="link_url" class="form-control" placeholder="https://example.com" required style="margin-bottom: 1rem;">
                            </div>
                            <button type="submit" class="btn btn-primary btn-small">Add Link</button>
                        </form>
                    </div>
                    
                    <!-- Recent Links -->
                    <?php if (empty($recent_links)): ?>
                        <div class="empty-state">
                            No links yet. Add your first link above!
                        </div>
                    <?php else: ?>
                        <?php foreach ($recent_links as $link): ?>
                            <div class="link-item">
                                <div class="link-info">
                                    <div class="link-name"><?= htmlspecialchars($link['name']) ?></div>
                                    <a href="<?= htmlspecialchars($link['url']) ?>" target="_blank" class="link-url">
                                        <?= htmlspecialchars($link['url']) ?>
                                    </a>
                                </div>
                                <div class="link-actions">
                                    <span style="font-size: 0.8rem; color: var(--text-muted);">
                                        <?= date('M j', strtotime($link['created_at'])) ?>
                                    </span>
                                    <a href="?id=<?= $company_id ?>&delete_link=<?= $link['id'] ?>" 
                                       class="delete-link" 
                                       onclick="return confirm('Delete this link?')">Delete</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Sidebar with Recent Activity -->
            <div>
                <!-- Recent Follow-ups -->
                <div class="card">
                    <h3 class="card-title">📅 Recent Follow-ups</h3>
                    <?php if (empty($recent_followups)): ?>
                        <div class="empty-state">No follow-ups yet.</div>
                    <?php else: ?>
                        <?php foreach ($recent_followups as $followup): ?>
                            <div class="followup-item priority-<?= $followup['priority'] ?>">
                                <div style="font-weight: 600; margin-bottom: 0.5rem;">
                                    <?= htmlspecialchars($followup['description']) ?>
                                </div>
                                <div style="font-size: 0.9rem; color: var(--text-muted);">
                                    <?= date('M j, Y', strtotime($followup['date'])) ?>
                                    <?php if ($followup['time']): ?>
                                        at <?= date('g:i A', strtotime($followup['time'])) ?>
                                    <?php endif; ?>
                                    <span class="status-badge status-<?= $followup['status'] ?>" style="margin-left: 0.5rem; padding: 0.25rem 0.75rem; font-size: 0.75rem;">
                                        <?= ucfirst($followup['status']) ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <!-- Recent People -->
                <div class="card">
                    <h3 class="card-title">👥 Recent People</h3>
                    <?php if (empty($recent_people)): ?>
                        <div class="empty-state">No people added yet.</div>
                    <?php else: ?>
                        <?php foreach ($recent_people as $person): ?>
                            <div class="contact-info">
                                <div style="font-weight: 600; margin-bottom: 0.25rem;">
                                    <?= htmlspecialchars($person['name']) ?>
                                    <?php if ($person['is_primary']): ?>
                                        <span style="color: var(--sidebar-active); font-size: 0.8rem;">(Primary)</span>
                                    <?php endif; ?>
                                </div>
                                <div style="font-size: 0.9rem; color: var(--text-muted);">
                                    <?= htmlspecialchars($person['role']) ?>
                                    <?php if ($person['department']): ?>
                                        - <?= htmlspecialchars($person['department']) ?>
                                    <?php endif; ?>
                                </div>
                                <?php if ($person['email']): ?>
                                    <div style="font-size: 0.85rem; margin-top: 0.25rem;">
                                        📧 <?= htmlspecialchars($person['email']) ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if (!empty($company['conversation_notes']) || !empty($company['website'])): ?>
            <div class="card" id="companyInfoCard" style="display: none;">
                <h3 class="card-title">🏢 Complete Company Information</h3>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem;">
                    <div>
                        <h4 style="color: var(--text-dark); font-weight: 700; margin-bottom: 1rem; display: flex; align-items: center; gap: 0.5rem;">
                            📋 Basic Information
                        </h4>
                        <div style="background: #f8fafc; padding: 1.5rem; border-radius: 12px; border: 1px solid var(--border);">
                            <div style="margin-bottom: 1rem;">
                                <strong>Company Name:</strong> <?= htmlspecialchars($company['name']) ?>
                            </div>
                            <div style="margin-bottom: 1rem;">
                                <strong>Status:</strong> 
                                <span class="status-badge status-<?= $company['status'] ?>" style="margin-left: 0.5rem;">
                                    <?= ucfirst($company['status']) ?>
                                </span>
                            </div>
                            <?php if ($company['website']): ?>
                                <div style="margin-bottom: 1rem;">
                                    <strong>Website:</strong> 
                                    <a href="<?= htmlspecialchars($company['website']) ?>" target="_blank" style="color: var(--sidebar-active); font-weight: 500;">
                                        <?= htmlspecialchars($company['website']) ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                            <div style="margin-bottom: 1rem;">
                                <strong>Reminder Period:</strong> <?= ucfirst(str_replace('_', ' ', $company['reminder_period'])) ?>
                            </div>
                            <?php if ($company['reminder_period'] === 'custom_datetime' && !empty($company['reminder_at'])): ?>
                                <div style="margin-bottom: 1rem;">
                                    <strong>Custom Reminder At:</strong> <?= date('F j, Y g:i A', strtotime($company['reminder_at'])) ?>
                                </div>
                            <?php elseif ($company['custom_reminder_days']): ?>
                                <div style="margin-bottom: 1rem;">
                                    <strong>Custom Reminder Days:</strong> <?= $company['custom_reminder_days'] ?> days
                                </div>
                            <?php endif; ?>
                            <div>
                                <strong>Date Added:</strong> <?= date('F j, Y g:i A', strtotime($company['created_at'])) ?>
                            </div>
                        </div>
                    </div>
                    
                    <?php if (!empty($company['conversation_notes'])): ?>
                        <div>
                            <h4 style="color: var(--text-dark); font-weight: 700; margin-bottom: 1rem; display: flex; align-items: center; gap: 0.5rem;">
                                💬 Initial Conversation Notes
                            </h4>
                            <div style="background: linear-gradient(135deg, #f0f9ff, #e0f2fe); padding: 1.5rem; border-radius: 12px; border-left: 4px solid var(--sidebar-active);">
                                <?= nl2br(htmlspecialchars($company['conversation_notes'])) ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </main>
    
    <script>
        function toggleCompanyInfo() {
            const card = document.getElementById('companyInfoCard');
            const btn = document.getElementById('toggleInfoBtn');
            
            if (card.style.display === 'none') {
                card.style.display = 'block';
                btn.textContent = 'Hide All Info';
                card.scrollIntoView({ behavior: 'smooth', block: 'start' });
            } else {
                card.style.display = 'none';
                btn.textContent = 'Show All Info';
            }
        }
    </script>
</body>
</html>
