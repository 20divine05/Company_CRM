<?php
require 'db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// --- Utility functions ---
function get_filters($src) {
    return [
        'date_from'   => trim($src['date_from'] ?? ''),
        'date_to'     => trim($src['date_to'] ?? ''),
        'status'      => trim($src['status'] ?? 'all'),
        'department'  => trim($src['department'] ?? 'all'),
        'search'      => trim($src['search'] ?? '')
    ];
}

function build_query($filters, &$params) {
    $where = ["1=1"]; // show all companies (no user filter)
    $params = [];

    if ($filters['date_from'] !== '') {
        $where[] = "c.created_at >= ?";
        $params[] = $filters['date_from'];
    }
    if ($filters['date_to'] !== '') {
        $where[] = "c.created_at <= ?";
        $params[] = $filters['date_to'] . " 23:59:59";
    }
    if ($filters['status'] !== '' && $filters['status'] !== 'all') {
        $where[] = "c.status = ?";
        $params[] = $filters['status'];
    }
    if ($filters['department'] !== '' && $filters['department'] !== 'all') {
        $where[] = "cp.department = ?";
        $params[] = $filters['department'];
    }
    if ($filters['search'] !== '') {
        $where[] = "(c.name LIKE ? OR c.website LIKE ?)";
        $params[] = "%" . $filters['search'] . "%";
        $params[] = "%" . $filters['search'] . "%";
    }

    $sql = "SELECT c.*, 
                   cp.name AS primary_contact_name,
                   cp.department AS department,
                   cp.email AS primary_contact_email,
                   cp.phone AS primary_contact_phone
            FROM companies c
            LEFT JOIN company_people cp ON cp.company_id = c.id AND cp.is_primary = 1
            WHERE " . implode(" AND ", $where) . "
            ORDER BY c.created_at DESC";
    return $sql;
}

// --- Handle filters ---
$action_download = isset($_GET['download']) && $_GET['download'] === 'csv';
$filters = $action_download ? get_filters($_GET) : (($_SERVER['REQUEST_METHOD']==='POST') ? get_filters($_POST) : [
    'date_from'=>'','date_to'=>'','status'=>'all','department'=>'all','search'=>''
]);

$params = [];
$sql = build_query($filters, $params);
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$companies = $stmt->fetchAll(PDO::FETCH_ASSOC);

// --- CSV download ---
if ($action_download) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="companies_report.csv"');
    $out = fopen('php://output','w');
    fputcsv($out,['Company','Website','Status','Created At','Primary Contact','Department','Email','Phone']);
    foreach ($companies as $c) {
        fputcsv($out,[
            $c['name'],
            $c['website'],
            $c['status'],
            $c['created_at'],
            $c['primary_contact_name'],
            $c['department'],
            $c['primary_contact_email'],
            $c['primary_contact_phone']
        ]);
    }
    fclose($out);
    exit;
}

// Build departments list
$dept_stmt = $pdo->prepare("SELECT DISTINCT department FROM company_people WHERE department IS NOT NULL AND department != ''");
$dept_stmt->execute();
$departments = $dept_stmt->fetchAll(PDO::FETCH_COLUMN);
$preset_departments = ['CSE','ISE','AI&ML','ECE','EEE','ME','CV','MBA','MCA','MTECH'];
$departments = array_values(array_unique(array_merge($preset_departments,$departments)));
sort($departments, SORT_NATURAL|SORT_FLAG_CASE);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Company Diary</title>
    <style>
        /* Updated to match modern dashboard design with dark sidebar */
        :root {
            --sidebar-bg: #1a1d29;
            --sidebar-text: #a1a5b7;
            --sidebar-active: #3b82f6;
            --main-bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --gradient-1: linear-gradient(135deg, #06b6d4, #3b82f6);
            --gradient-2: linear-gradient(135deg, #ec4899, #8b5cf6);
            --gradient-3: linear-gradient(135deg, #f59e0b, #ef4444);
            --gradient-4: linear-gradient(135deg, #10b981, #059669);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: var(--main-bg);
            color: var(--text-dark);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }

        /* Added consistent sidebar navigation */
        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            color: var(--sidebar-text);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            z-index: 1000;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 2rem;
        }

        .sidebar-header h1 {
            color: white;
            font-size: 1.5rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .sidebar-header .user-info {
            margin-top: 1rem;
            font-size: 0.9rem;
            opacity: 0.8;
            font-weight: 500;
        }

        .sidebar-nav {
            list-style: none;
            padding: 0 1rem;
        }

        .sidebar-nav li {
            margin-bottom: 0.5rem;
        }

        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.875rem 1rem;
            color: var(--sidebar-text);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: var(--sidebar-active);
            color: white;
            transform: translateX(4px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .sidebar-nav .icon {
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
        }

        .main-header {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 20px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border);
        }

        .main-header h1 {
            font-size: 2rem;
            font-weight: 800;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .main-header .breadcrumb {
            color: var(--text-muted);
            font-size: 1rem;
            font-weight: 500;
        }

        .card {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2.5rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            margin-bottom: 2rem;
            border: 1px solid var(--border);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
        }

        .card-title {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 2rem;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .filter-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            margin-bottom: 0.75rem;
            font-weight: 600;
            color: var(--text-dark);
            font-size: 0.95rem;
        }

        .form-control {
            width: 100%;
            padding: 1rem 1.25rem;
            border: 2px solid var(--border);
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: var(--card-bg);
            font-weight: 500;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--sidebar-active);
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem 2rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
            font-size: 1rem;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary { background: var(--gradient-1); color: white; }
        .btn-secondary { background: var(--gradient-2); color: white; }
        .btn-info { background: var(--gradient-4); color: white; }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        .table-container {
            overflow-x: auto;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        .table th,
        .table td {
            padding: 1.25rem;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }

        .table th {
            background: #f8fafc;
            font-weight: 700;
            color: var(--text-dark);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .table td {
            font-weight: 500;
        }

        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-prospect { 
            background: linear-gradient(135deg, #fef3c7, #fde68a);
            color: #92400e; 
        }
        .status-active { 
            background: linear-gradient(135deg, #d1fae5, #a7f3d0);
            color: #065f46; 
        }
        .status-client { 
            background: linear-gradient(135deg, #dbeafe, #bfdbfe);
            color: #1e40af; 
        }
        .status-inactive { 
            background: linear-gradient(135deg, #fee2e2, #fecaca);
            color: #991b1b; 
        }
        .status-interview_scheduled {
            background: linear-gradient(135deg, #e0e7ff, #c7d2fe);
            color: #3730a3; /* indigo-800 */
        }
        .status-completed {
            background: linear-gradient(135deg, #dcfce7, #bbf7d0);
            color: #065f46; /* emerald-800 */
        }

        .empty-state {
            text-align: center;
            color: var(--text-muted);
            padding: 4rem;
        }

        .empty-state h3 {
            margin-bottom: 1rem;
            color: var(--text-dark);
            font-size: 1.5rem;
            font-weight: 700;
        }

        .empty-state p {
            font-size: 1.1rem;
            margin-bottom: 2rem;
        }

        .filter-actions {
            display: flex;
            gap: 1.5rem;
            align-items: center;
            flex-wrap: wrap;
        }

        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }

            .main-content {
                margin-left: 0;
            }
        }

        @media (max-width: 768px) {
            .main-content { 
                padding: 1rem; 
            }
            .filter-grid { 
                grid-template-columns: 1fr; 
            }
            .filter-actions { 
                flex-direction: column; 
                align-items: stretch; 
            }
        }
    </style>
</head>
<body>
    <!-- Added consistent sidebar navigation -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h1>📊 BRAND</h1>
            <div class="user-info">
                Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!
            </div>
        </div>
        <nav>
            <ul class="sidebar-nav">
                <li><a href="dashboard.php"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="companies.php"><span class="icon">🏢</span> Companies</a></li>
                <li><a href="follow_ups.php"><span class="icon">📝</span> Follow-ups</a></li>
                <li><a href="analytics.php"><span class="icon">📈</span> Analytics</a></li>
                <li><a href="reports.php" class="active"><span class="icon">📋</span> Reports</a></li>
                
                <li><a href="logout.php"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
    </aside>

    <main class="main-content">
        <div class="main-header">
            <h1>📋 Reports</h1>
            <div class="breadcrumb">Dashboard / Reports</div>
        </div>
        
        <div class="card">
            <h2 class="card-title">📈 Generate Company Report</h2>
            
            <form method="POST">
                <div class="filter-grid">
                    <div class="form-group">
                        <label class="form-label">Date From</label>
                        <input type="date" name="date_from" class="form-control" value="<?= $filters['date_from'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Date To</label>
                        <input type="date" name="date_to" class="form-control" value="<?= $filters['date_to'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-control">
                            <option value="all">All Statuses</option>
                            <option value="prospect" <?= ($filters['status'] ?? '') === 'prospect' ? 'selected' : '' ?>>Prospect</option>
                            <option value="active" <?= ($filters['status'] ?? '') === 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="interview_scheduled" <?= ($filters['status'] ?? '') === 'interview_scheduled' ? 'selected' : '' ?>>Interview Scheduled</option>
                            <option value="completed" <?= ($filters['status'] ?? '') === 'completed' ? 'selected' : '' ?>>Completed</option>
                            <option value="inactive" <?= ($filters['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Department</label>
                        <select name="department" class="form-control">
                            <option value="all">All Departments</option>
                            <?php foreach ($departments as $dept): ?>
                                <option value="<?= htmlspecialchars($dept) ?>" <?= ($filters['department'] ?? '') === $dept ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($dept) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="filter-actions">
                    <button type="submit" class="btn btn-primary">🔍 Generate Report</button>
                    <?php if (!empty($companies)): ?>
                        <a href="?download=csv&<?= http_build_query($filters) ?>" class="btn btn-info">📥 Download CSV</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <?php if (!empty($companies)): ?>
        <div class="card">
            <h2 class="card-title">📋 Report Results (<?= count($companies) ?> companies)</h2>
            
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Company Name</th>
                            <th>Status</th>
                            <th>Website</th>
                            <th>Primary Contact</th>
                            <th>Department</th>
                            <th>Date Added</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($companies as $company): ?>
                        <tr>
                            <td>
                                <a href="company_dashboard.php?id=<?= $company['id'] ?>" style="color: var(--sidebar-active); text-decoration: none; font-weight: 600;">
                                    <?= htmlspecialchars($company['name']) ?>
                                </a>
                            </td>
                            <td>
                                <span class="status-badge status-<?= $company['status'] ?>">
                                    <?= ucfirst($company['status']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($company['website']): ?>
                                    <a href="<?= htmlspecialchars($company['website']) ?>" target="_blank" style="color: var(--sidebar-active); font-weight: 500;">
                                        <?= htmlspecialchars($company['website']) ?>
                                    </a>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($company['primary_contact_name']): ?>
                                    <strong><?= htmlspecialchars($company['primary_contact_name']) ?></strong>
                                    <?php if ($company['primary_contact_email']): ?>
                                        <br><small style="color: var(--text-muted);"><?= htmlspecialchars($company['primary_contact_email']) ?></small>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span style="color: var(--text-muted);">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td><?= $company['department'] ? htmlspecialchars($company['department']) : '<span style="color: var(--text-muted);">N/A</span>' ?></td>
                            <td><?= date('M j, Y', strtotime($company['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
        <div class="card">
            <div class="empty-state">
                <h3>No companies found</h3>
                <p>Try adjusting your filter criteria to see results.</p>
            </div>
        </div>
        <?php endif; ?>
    </main>
</body>
</html>
