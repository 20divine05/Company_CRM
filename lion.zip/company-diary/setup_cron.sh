#!/bin/bash

# Script to help set up the cron job for email reminders

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CRON_COMMAND="*/5 * * * * php $SCRIPT_DIR/cron_reminder.php >> $SCRIPT_DIR/cron_log.txt 2>&1"

echo "🔧 CRM Email Reminder Cron Setup"
echo "================================"
echo ""
echo "Current directory: $SCRIPT_DIR"
echo "Cron command: $CRON_COMMAND"
echo ""

# Check if cron is available
if command -v crontab &> /dev/null; then
    echo "✅ Crontab is available"
    
    # Show current cron jobs
    echo ""
    echo "📋 Current cron jobs:"
    crontab -l 2>/dev/null || echo "No cron jobs found"
    
    echo ""
    echo "To add the email reminder cron job, run:"
    echo "========================================"
    echo "(crontab -l 2>/dev/null; echo \"$CRON_COMMAND\") | crontab -"
    echo ""
    echo "Or manually add this line to your crontab (crontab -e):"
    echo "$CRON_COMMAND"
    
else
    echo "❌ Crontab not available on this system"
    echo ""
    echo "Alternative setup options:"
    echo "========================="
    echo "1. Use your hosting control panel's cron job feature"
    echo "2. Set up a scheduled task in Windows Task Scheduler"
    echo "3. Use a web-based cron service"
fi

echo ""
echo "🧪 Test the system:"
echo "=================="
echo "1. php debug_follow_ups.php    (check current status)"
echo "2. php check_reminders.php     (run manually)"
echo "3. php test_email.php          (test email config)"
echo ""
