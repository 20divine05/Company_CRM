<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/SMTP.php';
require_once __DIR__ . '/PHPMailer/Exception.php';

function sendEmail($to_emails, $subject, $body, $is_html = true) {
    $mail = new PHPMailer(true);
    
    try {
        $mail->SMTPDebug = 2; // Set to 0 to disable debugging once working
        $mail->Debugoutput = function($str, $level) {
            error_log("PHPMailer Debug Level $level: $str");
        };
        
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'pdtrak511@gmail.com';
        $mail->Password = 'oapg jojv gngr givh'; // Your app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true,
                'cafile' => false,
                'capath' => false,
                'ciphers' => 'HIGH:!SSLv2:!SSLv3'
            )
        );
        
        $mail->Timeout = 120;
        $mail->SMTPKeepAlive = true;

        $mail->setFrom('pdtrak511@gmail.com', 'Company Diary CRM');
        
        if (is_array($to_emails)) {
            $validEmails = 0;
            foreach ($to_emails as $email) {
                $email = trim($email);
                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $mail->addAddress($email);
                    $validEmails++;
                } else {
                    error_log("Invalid email address skipped: " . $email);
                }
            }
            if ($validEmails == 0) {
                throw new Exception("No valid email addresses found");
            }
        } else {
            $email = trim($to_emails);
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $mail->addAddress($email);
            } else {
                throw new Exception("Invalid email address: " . $email);
            }
        }

        $mail->isHTML($is_html);
        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->AltBody = strip_tags($body);
        $mail->CharSet = 'UTF-8';

        $result = $mail->send();
        $recipient_list = is_array($to_emails) ? implode(', ', $to_emails) : $to_emails;
        error_log("✅ EMAIL SUCCESS: Sent to " . $recipient_list);
        return true;
        
    } catch (Exception $e) {
        $recipient_list = is_array($to_emails) ? implode(', ', $to_emails) : $to_emails;
        error_log("❌ EMAIL FAILED: To " . $recipient_list . " - Error: " . $e->getMessage());
        error_log("❌ EMAIL DEBUG: SMTP Host: " . $mail->Host . ", Port: " . $mail->Port . ", Username: " . $mail->Username);
        return false;
    } finally {
        if (isset($mail)) {
            $mail->smtpClose();
        }
    }
}

function testEmailConnection(): bool {
    $mail = new PHPMailer(true);
    
    try {
        $mail->SMTPDebug = 0; // Disable debug for test
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'pdtrak511@gmail.com';
        $mail->Password = 'oapg jojv gngr givh';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->Timeout = 30;
        
        // Test connection
        if ($mail->smtpConnect()) {
            $mail->smtpClose();
            error_log("✅ EMAIL TEST SUCCESS: SMTP connection working");
            return true;
        } else {
            error_log("❌ EMAIL TEST FAILED: Could not connect to SMTP server");
            return false;
        }
    } catch (Exception $e) {
        error_log("❌ EMAIL TEST FAILED: " . $e->getMessage());
        return false;
    }
}

function sendFollowUpEmail($to_emails, $company_name, $description, $scheduled_date, $priority = 'medium') {
    $priority_colors = [
        'high' => '#ef4444',
        'medium' => '#f59e0b', 
        'low' => '#10b981'
    ];
    
    $priority_badge = '<span style="background: ' . ($priority_colors[strtolower($priority)] ?? '#6b7280') . '; color: white; padding: 4px 8px; border-radius: 4px; font-size: 12px;">' . strtoupper($priority) . ' PRIORITY</span>';
    
    $subject = "🔔 Follow-up Reminder: " . $company_name;
    
    $body = "
    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #f8f9fa; padding: 20px;'>
        <div style='background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>
            <h2 style='color: #1a1a2e; margin-bottom: 20px; border-bottom: 2px solid #00d4ff; padding-bottom: 10px;'>
                📅 Follow-up Reminder
            </h2>
            
            <div style='margin-bottom: 20px;'>
                <h3 style='color: #333; margin-bottom: 10px;'>Company: {$company_name}</h3>
                {$priority_badge}
            </div>
            
            <div style='background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;'>
                <strong>Description:</strong><br>
                {$description}
            </div>
            
            <div style='margin: 20px 0;'>
                <strong>Scheduled:</strong> " . date('l, F j, Y \a\t g:i A', strtotime($scheduled_date)) . "
            </div>
            
            <div style='margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; color: #666; font-size: 14px;'>
                <p>⚡ This is an automated reminder from Company Diary CRM</p>
                <p>Please log into your CRM to update the follow-up status.</p>
            </div>
        </div>
    </div>";
    
    return sendEmail($to_emails, $subject, $body, true);
}
?>
