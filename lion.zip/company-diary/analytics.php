<?php
require 'db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$companies_count = $pdo->prepare("SELECT COUNT(*) as count FROM companies");
$companies_count->execute();
$companies_total = $companies_count->fetch()['count'];

$people_count = $pdo->prepare("SELECT COUNT(*) as count FROM company_people");
$people_count->execute();
$people_total = $people_count->fetch()['count'];

$followups_count = $pdo->prepare("SELECT COUNT(*) as count FROM follow_ups WHERE status = 'pending'");
$followups_count->execute();
$followups_total = $followups_count->fetch()['count'];

$completed_followups = $pdo->prepare("SELECT COUNT(*) as count FROM follow_ups WHERE status = 'completed'");
$completed_followups->execute();
$completed_total = $completed_followups->fetch()['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - Company Diary</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Updated to match modern dashboard design with dark sidebar */
        :root {
            --sidebar-bg: #1a1d29;
            --sidebar-text: #a1a5b7;
            --sidebar-active: #3b82f6;
            --main-bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --gradient-1: linear-gradient(135deg, #06b6d4, #3b82f6);
            --gradient-2: linear-gradient(135deg, #ec4899, #8b5cf6);
            --gradient-3: linear-gradient(135deg, #f59e0b, #ef4444);
            --gradient-4: linear-gradient(135deg, #10b981, #059669);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: var(--main-bg);
            color: var(--text-dark);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }

        /* Added consistent sidebar navigation */
        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            color: var(--sidebar-text);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            z-index: 1000;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 2rem;
        }

        .sidebar-header h1 {
            color: white;
            font-size: 1.5rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .sidebar-header .user-info {
            margin-top: 1rem;
            font-size: 0.9rem;
            opacity: 0.8;
            font-weight: 500;
        }

        .sidebar-nav {
            list-style: none;
            padding: 0 1rem;
        }

        .sidebar-nav li {
            margin-bottom: 0.5rem;
        }

        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.875rem 1rem;
            color: var(--sidebar-text);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: var(--sidebar-active);
            color: white;
            transform: translateX(4px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .sidebar-nav .icon {
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
        }

        .main-header {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 20px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border);
        }

        .main-header h1 {
            font-size: 2rem;
            font-weight: 800;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .main-header .breadcrumb {
            color: var(--text-muted);
            font-size: 1rem;
            font-weight: 500;
        }

        /* Updated stats cards with modern gradients */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .stat-card {
            background: var(--card-bg);
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            border: 1px solid var(--border);
        }

        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            border-radius: 20px 20px 0 0;
        }

        .stat-card.companies::before { background: var(--gradient-1); }
        .stat-card.people::before { background: var(--gradient-2); }
        .stat-card.followups::before { background: var(--gradient-3); }
        .stat-card.completed::before { background: var(--gradient-4); }

        .stat-number {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 0.25rem;
        }

        .stat-card.companies .stat-number {
            background: var(--gradient-1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-card.people .stat-number {
            background: var(--gradient-2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-card.followups .stat-number {
            background: var(--gradient-3);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-card.completed .stat-number {
            background: var(--gradient-4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-label {
            color: var(--text-muted);
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* Updated chart containers with modern styling */
        .charts-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .chart-container {
            background: var(--card-bg);
            border-radius: 16px;
            padding: 1.5rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.06);
            margin-bottom: 1.5rem;
            border: 1px solid var(--border);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .chart-container:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        .chart-title {
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        /* Reduced chart canvas height from 300px to 200px for better proportions */
        .chart-canvas {
            height: 200px !important;
            width: 100% !important;
            position: relative;
            display: block;
        }

        .chart-container.full-width {
            grid-column: 1 / -1;
        }

        @media (max-width: 1024px) {
            .charts-grid {
                grid-template-columns: 1fr;
            }
            
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }

            .main-content {
                margin-left: 0;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 1rem;
            }

            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }

            .stat-card {
                padding: 1rem;
            }

            .stat-number {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <!-- Added consistent sidebar navigation -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h1>📊 BRAND</h1>
            <div class="user-info">
                Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!
            </div>
        </div>
        <nav>
            <ul class="sidebar-nav">
                <li><a href="dashboard.php"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="companies.php"><span class="icon">🏢</span> Companies</a></li>
                <li><a href="follow_ups.php"><span class="icon">📝</span> Follow-ups</a></li>
                <li><a href="analytics.php" class="active"><span class="icon">📈</span> Analytics</a></li>
                <li><a href="reports.php"><span class="icon">📋</span> Reports</a></li>
                <li><a href="logout.php"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
    </aside>

    <main class="main-content">
        <div class="main-header">
            <h1>📈 Analytics Dashboard</h1>
            <div class="breadcrumb">Dashboard / Analytics</div>
        </div>

        <div class="stats-grid">
            <div class="stat-card companies">
                <div class="stat-number"><?php echo $companies_total; ?></div>
                <div class="stat-label">Total Companies</div>
            </div>
            <div class="stat-card people">
                <div class="stat-number"><?php echo $people_total; ?></div>
                <div class="stat-label">Total Contacts</div>
            </div>
            <div class="stat-card followups">
                <div class="stat-number"><?php echo $followups_total; ?></div>
                <div class="stat-label">Pending Follow-ups</div>
            </div>
            <div class="stat-card completed">
                <div class="stat-number"><?php echo $completed_total; ?></div>
                <div class="stat-label">Completed Follow-ups</div>
            </div>
        </div>

        <div class="charts-grid">
            <div class="chart-container">
                <h3 class="chart-title">📈 Companies Growth Over Time</h3>
                <canvas id="companiesChart" class="chart-canvas"></canvas>
            </div>

            <div class="chart-container">
                <h3 class="chart-title">📊 Status Distribution</h3>
                <canvas id="statusChart" class="chart-canvas"></canvas>
            </div>
        </div>

        <div class="chart-container full-width">
            <h3 class="chart-title">📅 Follow-up Status Overview</h3>
            <canvas id="followupChart" class="chart-canvas"></canvas>
        </div>
    </main>

    <!-- Enhanced Chart.js scripts with modern gradients -->
    <script>
        Chart.defaults.animation = false;
        Chart.defaults.responsive = true;
        Chart.defaults.maintainAspectRatio = false;

        // Companies growth chart with gradient
        <?php
        $chart_stmt = $pdo->prepare("
            SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count 
            FROM companies 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
            GROUP BY DATE_FORMAT(created_at, '%Y-%m') 
            ORDER BY month ASC
        ");
        $chart_stmt->execute();
        $chart_data = $chart_stmt->fetchAll();
        
        $months = [];
        $counts = [];
        foreach ($chart_data as $data) {
            $months[] = date('M Y', strtotime($data['month'] . '-01'));
            $counts[] = $data['count'];
        }
        ?>
        
        const ctx1 = document.getElementById('companiesChart').getContext('2d');
        const gradient1 = ctx1.createLinearGradient(0, 0, 0, 200);
        gradient1.addColorStop(0, 'rgba(6, 182, 212, 0.8)');
        gradient1.addColorStop(1, 'rgba(6, 182, 212, 0.1)');
        
        const companiesChart = new Chart(ctx1, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($months); ?>,
                datasets: [{
                    label: 'Companies Added',
                    data: <?php echo json_encode($counts); ?>,
                    borderColor: '#06b6d4',
                    backgroundColor: gradient1,
                    borderWidth: 3,
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: '#06b6d4',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 3,
                    pointRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: false,
                interaction: {
                    intersect: false
                },
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1,
                            color: '#64748b',
                            font: { weight: 500 }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        ticks: {
                            color: '#64748b',
                            font: { weight: 500 }
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });

        // Company status chart with modern colors
        <?php
        $status_stmt = $pdo->prepare("
            SELECT status, COUNT(*) as count 
            FROM companies 
            GROUP BY status
        ");
        $status_stmt->execute();
        $status_data = $status_stmt->fetchAll();
        
        $statuses = [];
        $status_counts = [];
        foreach ($status_data as $data) {
            $statuses[] = ucfirst($data['status']);
            $status_counts[] = $data['count'];
        }
        ?>

        const ctx2 = document.getElementById('statusChart').getContext('2d');
        const statusChart = new Chart(ctx2, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($statuses); ?>,
                datasets: [{
                    data: <?php echo json_encode($status_counts); ?>,
                    backgroundColor: ['#06b6d4', '#ec4899', '#f59e0b', '#10b981'],
                    borderWidth: 0,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            font: { weight: 500 }
                        }
                    }
                }
            }
        });

        // Follow-up status chart with gradients
        const ctx3 = document.getElementById('followupChart').getContext('2d');
        const followupChart = new Chart(ctx3, {
            type: 'bar',
            data: {
                labels: ['Pending', 'Completed'],
                datasets: [{
                    label: 'Follow-ups',
                    data: [<?php echo $followups_total; ?>, <?php echo $completed_total; ?>],
                    backgroundColor: ['#f59e0b', '#10b981'],
                    borderRadius: 8,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1,
                            color: '#64748b',
                            font: { weight: 500 }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        ticks: {
                            color: '#64748b',
                            font: { weight: 500 }
                        },
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
