<?php
if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); };

// Database configuration
$host = 'localhost';
$dbname = 'company_diary';
$username = 'root';
$password = '';

try {
    // PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // MySQLi connection (for backward compatibility)
    $conn = new mysqli($host, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $conn->set_charset("utf8");
    
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}


// Kick lightweight on-load scheduler (runs at most once per minute)
require_once __DIR__ . '/onload_scheduler.php';
?>
