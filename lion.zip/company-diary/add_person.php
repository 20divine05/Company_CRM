<?php
require 'db.php';
if (!isset($_SESSION['user_id'])) { 
    header("Location: index.php"); 
    exit; 
}

$company_id = $_GET['company_id'] ?? null;
if (!$company_id) {
    header("Location: companies.php");
    exit;
}

// Fetch company
$stmt = $pdo->prepare("SELECT * FROM companies WHERE id = ?");
$stmt->execute([$company_id]);
$company = $stmt->fetch();

if (!$company) {
    header("Location: companies.php");
    exit;
}

$message = "";
$isSuccess = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $role  = trim($_POST['role']);
    
    if ($name) {
        // Notes removed from INSERT
        $stmt = $pdo->prepare("
            INSERT INTO company_people (company_id, name, email, phone, role)
            VALUES (?, ?, ?, ?, ?)
        ");
        if ($stmt->execute([$company_id, $name, $email, $phone, $role])) {
            $isSuccess = true;
            $message = "Contact added successfully!";
            // Clear form
            $_POST = array();
        } else {
            $message = "Error adding contact. Please try again.";
        }
    } else {
        $message = "Contact name is required.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Person - Company Diary</title>
    <style>
        /* Updated to match modern dashboard design with dark sidebar */
        :root {
            --sidebar-bg: #1a1d29;
            --sidebar-text: #a1a5b7;
            --sidebar-active: #3b82f6;
            --main-bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --gradient-1: linear-gradient(135deg, #06b6d4, #3b82f6);
            --gradient-2: linear-gradient(135deg, #ec4899, #8b5cf6);
            --gradient-3: linear-gradient(135deg, #f59e0b, #ef4444);
            --gradient-4: linear-gradient(135deg, #10b981, #059669);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: var(--main-bg);
            color: var(--text-dark);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }

        /* Added consistent sidebar navigation */
        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            color: var(--sidebar-text);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            z-index: 1000;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 2rem;
        }

        .sidebar-header h1 {
            color: white;
            font-size: 1.5rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .sidebar-header .user-info {
            margin-top: 1rem;
            font-size: 0.9rem;
            opacity: 0.8;
            font-weight: 500;
        }

        .sidebar-nav {
            list-style: none;
            padding: 0 1rem;
        }

        .sidebar-nav li {
            margin-bottom: 0.5rem;
        }

        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.875rem 1rem;
            color: var(--sidebar-text);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: var(--sidebar-active);
            color: white;
            transform: translateX(4px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .sidebar-nav .icon {
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
        }

        .main-header {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 20px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border);
        }

        .main-header h1 {
            font-size: 2rem;
            font-weight: 800;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .main-header .breadcrumb {
            color: var(--text-muted);
            font-size: 1rem;
            font-weight: 500;
        }

        .breadcrumb a {
            color: var(--sidebar-active);
            text-decoration: none;
            font-weight: 600;
        }

        .breadcrumb a:hover {
            text-decoration: underline;
        }

        .company-name {
            color: var(--sidebar-active);
            font-weight: 700;
        }

        .card {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2.5rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            border: 1px solid var(--border);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .form-group {
            margin-bottom: 2rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.75rem;
            color: var(--text-dark);
            font-weight: 600;
            font-size: 0.95rem;
        }

        .form-control {
            width: 100%;
            padding: 1rem 1.25rem;
            border: 2px solid var(--border);
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: var(--card-bg);
            font-weight: 500;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--sidebar-active);
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.1);
        }

        textarea.form-control {
            resize: vertical;
            min-height: 120px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem 2rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
            font-size: 1rem;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: var(--gradient-1);
            color: white;
        }

        .btn-secondary {
            background: var(--gradient-2);
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        .form-actions {
            display: flex;
            gap: 1.5rem;
            margin-top: 3rem;
        }

        .alert {
            padding: 1.25rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            font-weight: 600;
            font-size: 1rem;
        }

        .alert-success {
            background: linear-gradient(135deg, #f0fdf4, #dcfce7);
            color: var(--gradient-4);
            border: 1px solid #bbf7d0;
        }

        .alert-error {
            background: linear-gradient(135deg, #fef2f2, #fee2e2);
            color: var(--gradient-3);
            border: 1px solid #fecaca;
        }

        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }

            .main-content {
                margin-left: 0;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 1rem;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .form-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <!-- Added consistent sidebar navigation -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h1>📊 BRAND</h1>
            <div class="user-info">
                Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!
            </div>
        </div>
        <nav>
            <ul class="sidebar-nav">
                <li><a href="dashboard.php"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="companies.php"><span class="icon">🏢</span> Companies</a></li>
                <li><a href="follow_ups.php"><span class="icon">📝</span> Follow-ups</a></li>
               <li><a href="analytics.php"><span class="icon">📈</span> Analytics</a></li>
                <li><a href="reports.php"><span class="icon">📋</span> Reports</a></li>
                
                <li><a href="logout.php"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
    </aside>

    <main class="main-content">
        <div class="main-header">
            <h1>👤 Add New Contact</h1>
            <div class="breadcrumb">
                <a href="companies.php">Companies</a> / 
                <a href="people.php?company_id=<?= $company['id'] ?>"><?= htmlspecialchars($company['name']) ?></a> / 
                Add Person
            </div>
        </div>

        <div class="card">
            <?php if ($message): ?>
                <div class="alert <?php echo $isSuccess ? 'alert-success' : 'alert-error'; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label for="name">Full Name *</label>
                    <input type="text" id="name" name="name" class="form-control" required 
                           value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="tel" id="phone" name="phone" class="form-control" 
                               value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="role">Role/Position</label>
                    <input type="text" id="role" name="role" class="form-control" 
                           placeholder="e.g., CEO, Sales Manager, Developer"
                           value="<?php echo htmlspecialchars($_POST['role'] ?? ''); ?>">
                </div>

                

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">👤 Save Contact</button>
                    <a href="people.php?company_id=<?= $company['id'] ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </main>
</body>
</html>
