<?php
require 'db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$companies_count = $pdo->prepare("SELECT COUNT(*) as count FROM companies");
$companies_count->execute();
$companies_total = $companies_count->fetch()['count'];

$people_count = $pdo->prepare("SELECT COUNT(*) as count FROM company_people");
$people_count->execute();
$people_total = $people_count->fetch()['count'];

$followups_count = $pdo->prepare("SELECT COUNT(*) as count FROM follow_ups WHERE status = 'pending'");
$followups_count->execute();
$followups_total = $followups_count->fetch()['count'];

$activity_stmt = $pdo->prepare("
    SELECT 
        DAYNAME(created_at) as day_name,
        COUNT(*) as count 
    FROM companies 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DAYNAME(created_at), DAYOFWEEK(created_at)
    ORDER BY DAYOFWEEK(created_at)
");
$activity_stmt->execute();
$activity_data = $activity_stmt->fetchAll();

$days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
$company_counts = array_fill(0, 7, 0);

foreach ($activity_data as $data) {
    $day_index = array_search($data['day_name'], $days);
    if ($day_index !== false) {
        $company_counts[$day_index] = $data['count'];
    }
}

$followup_stmt = $pdo->prepare("
    SELECT 
        DAYNAME(created_at) as day_name,
        COUNT(*) as count 
    FROM follow_ups
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DAYNAME(created_at), DAYOFWEEK(created_at)
    ORDER BY DAYOFWEEK(created_at)
");
$followup_stmt->execute();
$followup_data = $followup_stmt->fetchAll();

$followup_counts = array_fill(0, 7, 0);

foreach ($followup_data as $data) {
    $day_index = array_search($data['day_name'], $days);
    if ($day_index !== false) {
        $followup_counts[$day_index] = $data['count'];
    }
}

$people_stmt = $pdo->prepare("
    SELECT 
        DAYNAME(created_at) as day_name,
        COUNT(*) as count 
    FROM company_people
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DAYNAME(created_at), DAYOFWEEK(created_at)
    ORDER BY DAYOFWEEK(created_at)
");
$people_stmt->execute();
$people_data = $people_stmt->fetchAll();

$people_counts = array_fill(0, 7, 0);

foreach ($people_data as $data) {
    $day_index = array_search($data['day_name'], $days);
    if ($day_index !== false) {
        $people_counts[$day_index] = $data['count'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Company Diary</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Updated to match reference design with dark sidebar and modern gradients */
        :root {
            --sidebar-bg: #1a1d29;
            --sidebar-text: #a1a5b7;
            --sidebar-active: #3b82f6;
            --main-bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --gradient-1: linear-gradient(135deg, #06b6d4, #3b82f6);
            --gradient-2: linear-gradient(135deg, #ec4899, #8b5cf6);
            --gradient-3: linear-gradient(135deg, #f59e0b, #ef4444);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: var(--main-bg);
            color: var(--text-dark);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }

        /* Added dark sidebar navigation matching reference design */
        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            color: var(--sidebar-text);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            z-index: 1000;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 2rem;
        }

        .sidebar-header h1 {
            color: white;
            font-size: 1.5rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .sidebar-header .user-info {
            margin-top: 1rem;
            font-size: 0.9rem;
            opacity: 0.8;
            font-weight: 500;
        }

        .sidebar-nav {
            list-style: none;
            padding: 0 1rem;
        }

        .sidebar-nav li {
            margin-bottom: 0.5rem;
        }

        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.875rem 1rem;
            color: var(--sidebar-text);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: var(--sidebar-active);
            color: white;
            transform: translateX(4px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .sidebar-nav .icon {
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }

        /* Updated main content area to accommodate sidebar */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
        }

        .main-header {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 20px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border);
        }

        .main-header h1 {
            font-size: 2rem;
            font-weight: 800;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .main-header .breadcrumb {
            color: var(--text-muted);
            font-size: 1rem;
            font-weight: 500;
        }

        /* Updated stats cards with gradient backgrounds matching reference */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--card-bg);
            padding: 2.5rem;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            border: 1px solid var(--border);
        }

        .stat-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            border-radius: 20px 20px 0 0;
        }

        .stat-card.companies::before { background: var(--gradient-1); }
        .stat-card.people::before { background: var(--gradient-2); }
        .stat-card.followups::before { background: var(--gradient-3); }

        .stat-number {
            font-size: 3.5rem;
            font-weight: 800;
            margin-bottom: 0.75rem;
            background: linear-gradient(135deg, #3b82f6, #06b6d4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-card.people .stat-number {
            background: linear-gradient(135deg, #ec4899, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-card.followups .stat-number {
            background: linear-gradient(135deg, #f59e0b, #ef4444);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-label {
            color: var(--text-muted);
            font-size: 1.1rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        /* Added chart section matching reference design */
        .chart-section {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            border: 1px solid var(--border);
        }

        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .chart-header h2 {
            font-size: 1.75rem;
            font-weight: 700;
            color: var(--text-dark);
        }

        .chart-filters {
            display: flex;
            gap: 0.5rem;
        }

        .filter-btn {
            padding: 0.75rem 1.25rem;
            border: none;
            border-radius: 25px;
            background: #f1f5f9;
            color: var(--text-muted);
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .filter-btn.active {
            background: var(--sidebar-active);
            color: white;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .filter-btn:hover:not(.active) {
            background: #e2e8f0;
        }

        .chart-container {
            height: 400px;
            position: relative;
        }

        .main-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 2rem;
        }

        .card {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2.5rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            border: 1px solid var(--border);
            transition: all 0.3s ease;
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
        }

        .card h2 {
            color: var(--text-dark);
            margin-bottom: 2rem;
            font-size: 1.5rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .quick-actions {
            display: grid;
            gap: 1.25rem;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 1rem;
            padding: 1.25rem 1.75rem;
            border: none;
            border-radius: 16px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
            font-size: 1rem;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: var(--gradient-1);
            color: white;
        }

        .btn-secondary {
            background: var(--gradient-2);
            color: white;
        }

        .btn-warning {
            background: var(--gradient-3);
            color: white;
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.2);
        }

        .list {
            list-style: none;
        }

        .list li {
            padding: 1.25rem 0;
            border-bottom: 1px solid var(--border);
            color: var(--text-muted);
            transition: all 0.3s ease;
        }

        .list li:hover {
            background: #f8fafc;
            margin: 0 -1rem;
            padding-left: 1rem;
            padding-right: 1rem;
            border-radius: 8px;
        }

        .list li:last-child {
            border-bottom: none;
        }

        .list li strong {
            color: var(--text-dark);
            font-weight: 600;
        }

        .empty-state {
            text-align: center;
            color: var(--text-muted);
            font-style: italic;
            padding: 3rem;
            font-size: 1.1rem;
        }

        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }

            .main-content {
                margin-left: 0;
            }

            .main-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .main-content {
                padding: 1rem;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .chart-header {
                flex-direction: column;
                gap: 1rem;
                align-items: stretch;
            }
        }
    </style>
</head>
<body>
    <!-- Added dark sidebar navigation matching reference design -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h1>📊 BRAND</h1>
            <div class="user-info">
                Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!
            </div>
        </div>
        <nav>
            <ul class="sidebar-nav">
                <li><a href="dashboard.php" class="active"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="companies.php"><span class="icon">🏢</span> Companies</a></li>
                <li><a href="follow_ups.php"><span class="icon">📝</span> Follow-ups</a></li>
                <li><a href="analytics.php"><span class="icon">📈</span> Analytics</a></li>
                <li><a href="reports.php"><span class="icon">📋</span> Reports</a></li>
                <li><a href="logout.php"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
    </aside>

    <main class="main-content">
        <div class="main-header">
            <h1>Project Activity</h1>
            <div class="breadcrumb">Dashboard / Overview</div>
        </div>

        <div class="stats-grid">
            <div class="stat-card companies">
                <div class="stat-number"><?php echo $companies_total; ?></div>
                <div class="stat-label">Total Companies</div>
            </div>
            <div class="stat-card people">
                <div class="stat-number"><?php echo $people_total; ?></div>
                <div class="stat-label">Total Contacts</div>
            </div>
            <div class="stat-card followups">
                <div class="stat-number"><?php echo $followups_total; ?></div>
                <div class="stat-label">Pending Follow-ups</div>
            </div>
        </div>

        <!-- Added colorful chart section matching reference design -->
        <div class="chart-section">
            <div class="chart-header">
                <h2>Activity Overview</h2>
                <div class="chart-filters">
                    <button class="filter-btn">Monthly</button>
                    <button class="filter-btn">Weekly</button>
                    <button class="filter-btn active">Daily</button>
                    <button class="filter-btn">Completed</button>
                </div>
            </div>
            <div class="chart-container">
                <canvas id="activityChart"></canvas>
            </div>
        </div>

        <div class="main-grid">
            <div class="card">
                <h2>🚀 Quick Actions</h2>
                <div class="quick-actions">
                    <a href="add_company.php" class="btn btn-primary">➕ Add New Company</a>
                    <a href="add_followup.php" class="btn btn-secondary">📝 Schedule Follow-up</a>
                    <a href="companies.php" class="btn btn-warning">📋 View All Companies</a>
                </div>
            </div>

            <div class="card">
                <h2>🏢 Recent Companies</h2>
                <ul class="list">
                    <?php
                    $stmt = $pdo->prepare("SELECT name, created_at FROM companies ORDER BY created_at DESC LIMIT 5");
                    $stmt->execute();
                    $recent_companies = $stmt->fetchAll();
                    
                    if ($recent_companies) {
                        foreach ($recent_companies as $company) {
                            echo "<li><strong>" . htmlspecialchars($company['name']) . "</strong><br>";
                            echo "<small>Added " . date('M j, Y', strtotime($company['created_at'])) . "</small></li>";
                        }
                    } else {
                        echo "<li class='empty-state'>No companies added yet</li>";
                    }
                    ?>
                </ul>
            </div>
        </div>

        <div class="card" style="margin-top: 2rem;">
            <h2>📅 Upcoming Follow-ups</h2>
            <ul class="list">
                <?php
                $stmt = $pdo->prepare("SELECT f.description, f.date, c.name AS company_name 
                                     FROM follow_ups f 
                                     JOIN companies c ON f.company_id = c.id 
                                     WHERE f.date >= CURDATE() AND f.status = 'pending'
                                     ORDER BY f.date ASC LIMIT 5");
                $stmt->execute();
                $upcoming_followups = $stmt->fetchAll();
                
                if ($upcoming_followups) {
                    foreach ($upcoming_followups as $followup) {
                        echo "<li><strong>" . htmlspecialchars($followup['company_name']) . ":</strong> ";
                        echo htmlspecialchars($followup['description']);
                        echo "<br><small>Due: " . date('M j, Y', strtotime($followup['date'])) . "</small></li>";
                    }
                } else {
                    echo "<li class='empty-state'>No upcoming follow-ups</li>";
                }
                ?>
            </ul>
        </div>
    </main>

    <!-- Added Chart.js script for colorful gradient charts -->
    <script>
        // Create gradient chart matching reference design
        const ctx = document.getElementById('activityChart').getContext('2d');
        
        // Create gradients
        const gradient1 = ctx.createLinearGradient(0, 0, 0, 400);
        gradient1.addColorStop(0, 'rgba(6, 182, 212, 0.8)');
        gradient1.addColorStop(1, 'rgba(6, 182, 212, 0.1)');
        
        const gradient2 = ctx.createLinearGradient(0, 0, 0, 400);
        gradient2.addColorStop(0, 'rgba(236, 72, 153, 0.8)');
        gradient2.addColorStop(1, 'rgba(236, 72, 153, 0.1)');
        
        const gradient3 = ctx.createLinearGradient(0, 0, 0, 400);
        gradient3.addColorStop(0, 'rgba(245, 158, 11, 0.8)');
        gradient3.addColorStop(1, 'rgba(245, 158, 11, 0.1)');

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($days); ?>,
                datasets: [{
                    label: 'Companies',
                    data: <?php echo json_encode($company_counts); ?>,
                    backgroundColor: gradient1,
                    borderColor: '#06b6d4',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#06b6d4',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 3,
                    pointRadius: 6
                }, {
                    label: 'Follow-ups',
                    data: <?php echo json_encode($followup_counts); ?>,
                    backgroundColor: gradient2,
                    borderColor: '#ec4899',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#ec4899',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 3,
                    pointRadius: 6
                }, {
                    label: 'Contacts',
                    data: <?php echo json_encode($people_counts); ?>,
                    backgroundColor: gradient3,
                    borderColor: '#f59e0b',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: '#f59e0b',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 3,
                    pointRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            color: '#64748b',
                            font: {
                                weight: 500
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#64748b',
                            font: {
                                weight: 500
                            }
                        }
                    }
                },
                elements: {
                    point: {
                        hoverRadius: 10
                    }
                }
            }
        });
    </script>
</body>
</html>
