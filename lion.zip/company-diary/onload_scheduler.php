<?php
// Runs on every page load (when db.php is included). Processes due emails if at least 60s passed since last run.
try {
    $flag = __DIR__ . '/_onload_check.flag';
    $interval = 60; // seconds
    $now = time();
    $last = @intval(@file_get_contents($flag));
    if ($last <= 0 || ($now - $last) >= $interval) {
        // Update flag first to avoid overlap, then run
        @file_put_contents($flag, (string)$now, LOCK_EX);
        require_once __DIR__ . '/check_reminders.php';
        if (function_exists('checkReminders')) {
            checkReminders();
        }
    }
} catch (Throwable $e) {
    error_log("Onload scheduler error: " . $e->getMessage());
}
?>
