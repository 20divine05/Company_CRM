<?php
require 'db.php';
if (!isset($_SESSION['user_id'])) { 
    header("Location: index.php"); 
    exit; 
}

// Handle status update
if (isset($_POST['update_status'])) {
    $followup_id = $_POST['followup_id'];
    $status = $_POST['status'];
    
    $stmt = $pdo->prepare("UPDATE follow_ups SET status = ? WHERE id = ?");
    $stmt->execute([$status, $followup_id]);
    header("Location: follow_ups.php");
    exit;
}

// Handle delete
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM follow_ups WHERE id = ?");
    $stmt->execute([$_GET['delete']]);
    header("Location: follow_ups.php");
    exit;
}

// Fetch follow-ups
$stmt = $pdo->prepare("SELECT f.*, c.name as company_name 
                       FROM follow_ups f 
                       JOIN companies c ON f.company_id = c.id 
                       ORDER BY f.date ASC, f.status ASC");
$stmt->execute();
$followups = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Follow-ups - Company Diary</title>
    <style>
        /* Updated to match modern dashboard design with dark sidebar */
        :root {
            --sidebar-bg: #1a1d29;
            --sidebar-text: #a1a5b7;
            --sidebar-active: #3b82f6;
            --main-bg: #f8fafc;
            --card-bg: #ffffff;
            --text-dark: #1e293b;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --gradient-1: linear-gradient(135deg, #06b6d4, #3b82f6);
            --gradient-2: linear-gradient(135deg, #ec4899, #8b5cf6);
            --gradient-3: linear-gradient(135deg, #f59e0b, #ef4444);
            --gradient-4: linear-gradient(135deg, #10b981, #059669);
            --shadow-lg: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: var(--main-bg);
            color: var(--text-dark);
            line-height: 1.6;
            display: flex;
            min-height: 100vh;
        }

        /* Added consistent sidebar navigation */
        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            color: var(--sidebar-text);
            padding: 2rem 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.15);
            z-index: 1000;
        }

        .sidebar-header {
            padding: 0 2rem 2rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 2rem;
        }

        .sidebar-header h1 {
            color: white;
            font-size: 1.5rem;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .sidebar-header .user-info {
            margin-top: 1rem;
            font-size: 0.9rem;
            opacity: 0.8;
            font-weight: 500;
        }

        .sidebar-nav {
            list-style: none;
            padding: 0 1rem;
        }

        .sidebar-nav li {
            margin-bottom: 0.5rem;
        }

        .sidebar-nav a {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.875rem 1rem;
            color: var(--sidebar-text);
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .sidebar-nav a:hover,
        .sidebar-nav a.active {
            background: var(--sidebar-active);
            color: white;
            transform: translateX(4px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        .sidebar-nav .icon {
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
        }

        .main-header {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 20px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border);
        }

        .main-header h1 {
            font-size: 2rem;
            font-weight: 800;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .main-header .breadcrumb {
            color: var(--text-muted);
            font-size: 1rem;
            font-weight: 500;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem 1.5rem;
            border: none;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            cursor: pointer;
            font-size: 0.95rem;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-primary {
            background: var(--gradient-1);
            color: white;
        }

        .btn-secondary {
            background: var(--gradient-2);
            color: white;
        }

        .btn-warning {
            background: var(--gradient-3);
            color: white;
        }

        .btn-danger {
            background: var(--gradient-4);
            color: white;
        }

        .btn-sm {
            padding: 0.5rem 0.75rem;
            font-size: 0.85rem;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
        }

        .followup-grid {
            display: grid;
            gap: 2rem;
        }

        .followup-card {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
            border-left: 6px solid;
            transition: all 0.3s ease;
            border: 1px solid var(--border);
        }

        .followup-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.12);
        }

        .followup-card.pending {
            border-left-color: #f59e0b;
        }

        .followup-card.completed {
            border-left-color: #10b981;
            opacity: 0.9;
        }

        .followup-card.overdue {
            border-left-color: #ef4444;
        }

        .followup-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1.5rem;
        }

        .company-name {
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .followup-date {
            font-size: 1rem;
            color: var(--text-muted);
            font-weight: 500;
        }

        .followup-date.overdue {
            color: #ef4444;
            font-weight: 600;
        }

        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 25px;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-badge.pending {
            background: linear-gradient(135deg, #fef3c7, #fde68a);
            color: #92400e;
        }

        .status-badge.completed {
            background: linear-gradient(135deg, #d1fae5, #a7f3d0);
            color: #065f46;
        }

        .followup-description {
            color: var(--text-muted);
            margin-bottom: 2rem;
            line-height: 1.6;
            font-size: 1rem;
        }

        .followup-actions {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .empty-state {
            text-align: center;
            padding: 4rem;
            color: var(--text-muted);
        }

        .empty-state h3 {
            margin-bottom: 1rem;
            color: var(--text-dark);
            font-size: 1.5rem;
            font-weight: 700;
        }

        .empty-state p {
            font-size: 1.1rem;
            margin-bottom: 2rem;
        }

        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }

            .main-content {
                margin-left: 0;
            }
        }

        @media (max-width: 768px) {
            .page-header {
                flex-direction: column;
                gap: 1rem;
                align-items: stretch;
            }

            .main-content {
                padding: 1rem;
            }

            .followup-header {
                flex-direction: column;
                gap: 1rem;
            }

            .followup-actions {
                flex-direction: column;
            }
        }
    </style>
    <script>
        let refreshInterval;
        
        function startAutoRefresh() {
            refreshInterval = setInterval(refreshPage, 60000); // Refresh every 60 seconds
            showNotification('Auto-refresh enabled - page will update every minute', 'success');
        }
        
        function stopAutoRefresh() {
            clearInterval(refreshInterval);
            showNotification('Auto-refresh disabled', 'info');
        }
        
        function refreshPage() {
            // Add a subtle loading indicator
            document.body.style.opacity = '0.9';
            location.reload();
        }
        
        function showNotification(message, type) {
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed; top: 20px; right: 20px; z-index: 9999;
                padding: 12px 20px; border-radius: 8px; color: white;
                font-weight: 500; box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
            `;
            notification.textContent = message;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }
        
        // Check for recently updated follow-ups and highlight them
        function highlightRecentUpdates() {
            const cards = document.querySelectorAll('.followup-card');
            cards.forEach(card => {
                const statusBadge = card.querySelector('.status-badge');
                if (statusBadge && statusBadge.textContent.trim() === 'completed') {
                    // Add a subtle glow effect for recently completed items
                    card.style.boxShadow = '0 0 20px rgba(16, 185, 129, 0.3)';
                    setTimeout(() => {
                        card.style.boxShadow = '';
                    }, 5000);
                }
            });
        }
        
        // Start auto-refresh when page loads
        window.onload = function() {
            startAutoRefresh();
            highlightRecentUpdates();
            
            // Add refresh controls to the page
            const pageHeader = document.querySelector('.page-header');
            if (pageHeader) {
                const refreshControls = document.createElement('div');
                refreshControls.innerHTML = `
                    <button onclick="refreshPage()" class="btn btn-secondary btn-sm" style="margin-right: 10px;">
                        🔄 Refresh Now
                    </button>
                    <button onclick="stopAutoRefresh()" class="btn btn-warning btn-sm">
                        ⏸️ Stop Auto-refresh
                    </button>
                `;
                pageHeader.appendChild(refreshControls);
            }
        };
    </script>
</head>
<body>
    <!-- Added status indicator for real-time updates -->
    <div style="position: fixed; top: 10px; left: 50%; transform: translateX(-50%); background: #3b82f6; color: white; padding: 8px 16px; border-radius: 20px; font-size: 0.9rem; z-index: 1000;">
        📡 Live Updates: ON | Last check: <span id="lastUpdate"><?php echo date('H:i:s'); ?></span>
    </div>

    <!-- Added consistent sidebar navigation -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h1>📊 BRAND</h1>
            <div class="user-info">
                Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!
            </div>
        </div>
        <nav>
            <ul class="sidebar-nav">
                <li><a href="dashboard.php"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="companies.php"><span class="icon">🏢</span> Companies</a></li>
                <li><a href="follow_ups.php" class="active"><span class="icon">📝</span> Follow-ups</a></li>
                <li><a href="analytics.php"><span class="icon">📈</span> Analytics</a></li>
                <li><a href="reports.php"><span class="icon">📋</span> Reports</a></li>
                
                <li><a href="logout.php"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
    </aside>

    <main class="main-content">
        <div class="main-header">
            <h1>📝 Follow-ups</h1>
            <div class="breadcrumb">Dashboard / Follow-ups</div>
        </div>
        
        <div class="page-header">
            <div>
                <!-- Added real-time statistics display -->
                <div style="display: flex; gap: 20px; margin-bottom: 10px;">
                    <span style="background: #f59e0b; color: white; padding: 4px 12px; border-radius: 20px; font-size: 0.9rem;">
                        📋 Pending: <?php 
                        $pendingCount = 0;
                        foreach($followups as $f) {
                            if($f['status'] == 'pending') $pendingCount++;
                        }
                        echo $pendingCount;
                        ?>
                    </span>
                    <span style="background: #10b981; color: white; padding: 4px 12px; border-radius: 20px; font-size: 0.9rem;">
                        ✅ Completed: <?php 
                        $completedCount = 0;
                        foreach($followups as $f) {
                            if($f['status'] == 'completed') $completedCount++;
                        }
                        echo $completedCount;
                        ?>
                    </span>
                    <span style="background: #ef4444; color: white; padding: 4px 12px; border-radius: 20px; font-size: 0.9rem;">
                        ⚠️ Overdue: <?php 
                        $overdueCount = 0;
                        foreach($followups as $f) {
                            if($f['status'] == 'pending' && strtotime($f['date']) < strtotime('today')) $overdueCount++;
                        }
                        echo $overdueCount;
                        ?>
                    </span>
                </div>
            </div>
            <div style="display: flex; gap: 10px;">
                <a href="cron_status.php" class="btn btn-secondary">📊 System Status</a>
                <a href="add_followup.php" class="btn btn-primary">📅 Schedule Follow-up</a>
            </div>
        </div>

        <?php if (count($followups) > 0): ?>
            <div class="followup-grid">
                <?php foreach ($followups as $followup): 
                    $isOverdue = $followup['status'] == 'pending' && strtotime($followup['date']) < strtotime('today');
                    $cardClass = $followup['status'] == 'completed' ? 'completed' : ($isOverdue ? 'overdue' : 'pending');
                ?>
                    <div class="followup-card <?= $cardClass ?>">
                        <div class="followup-header">
                            <div>
                                <div class="company-name"><?= htmlspecialchars($followup['company_name']) ?></div>
                                <div class="followup-date <?= $isOverdue ? 'overdue' : '' ?>">
                                    <?php 
                                    $date = date('M j, Y', strtotime($followup['date']));
                                    $time = $followup['time'] ? date('g:i A', strtotime($followup['time'])) : '9:00 AM';
                                    if ($isOverdue) {
                                        echo "⚠️ Overdue: " . $date . " at " . $time;
                                    } else {
                                        echo "📅 " . $date . " at " . $time;
                                    }
                                    ?>
                                </div>
                            </div>
                            <span class="status-badge <?= $followup['status'] ?>">
                                <?= $followup['status'] ?>
                            </span>
                        </div>
                        
                        <div class="followup-description">
                            <?= htmlspecialchars($followup['description']) ?>
                            <!-- Added email status indicator -->
                            <?php if ($followup['email_sent'] == 1): ?>
                                <div style="margin-top: 10px; padding: 8px; background: #d1fae5; color: #065f46; border-radius: 6px; font-size: 0.9rem;">
                                    ✅ Email reminder sent successfully
                                </div>
                            <?php elseif ($followup['reminder_email'] == 1 && $followup['status'] == 'completed' && $followup['email_sent'] == 0): ?>
                                <div style="margin-top: 10px; padding: 8px; background: #fee2e2; color: #991b1b; border-radius: 6px; font-size: 0.9rem;">
                                    ⚠️ Email reminder failed - completed automatically
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="followup-actions">
                            <?php if ($followup['status'] == 'pending'): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="followup_id" value="<?= $followup['id'] ?>">
                                    <input type="hidden" name="status" value="completed">
                                    <button type="submit" name="update_status" class="btn btn-secondary btn-sm">
                                        ✅ Mark Complete
                                    </button>
                                </form>
                            <?php else: ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="followup_id" value="<?= $followup['id'] ?>">
                                    <input type="hidden" name="status" value="pending">
                                    <button type="submit" name="update_status" class="btn btn-warning btn-sm">
                                        🔄 Mark Pending
                                    </button>
                                </form>
                            <?php endif; ?>
                            
                            <a class="btn btn-danger btn-sm" href="follow_ups.php?delete=<?= $followup['id'] ?>" 
                               onclick="return confirm('Are you sure you want to delete this follow-up?')">
                                🗑️ Delete
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h3>No Follow-ups Scheduled</h3>
                <p>Stay organized by scheduling follow-ups with your companies.</p>
                <a href="add_followup.php" class="btn btn-primary">📅 Schedule Your First Follow-up</a>
            </div>
        <?php endif; ?>
    </main>
</body>
</html>
